var t = getApp(), a = require("../common/common.js");

Page({
    data: {
        pagePath: "../coupon/coupon",
        nav: [ "待领取", "未使用", "已使用", "已过期" ],
        curr: 1
    },
    tab: function(t) {
        var a = this, n = t.currentTarget.dataset.index;
        n != a.data.curr && (a.setData({
            curr: n,
            list: []
        }), a.getData());
    },
    setcoupon: function(a) {
        var n = this, o = a.currentTarget.dataset.index;
        wx.showModal({
            title: "提示",
            content: "是否领取优惠券？",
            success: function(a) {
                a.confirm ? t.util.request({
                    url: "entry/wxapp/user",
                    data: {
                        op: "set_coupon",
                        id: n.data.list[o].id
                    },
                    showLoading: !1,
                    success: function(t) {
                        if ("" != t.data.data) {
                            wx.showToast({
                                title: "领取成功",
                                icon: "success",
                                duration: 2e3
                            });
                            var a = n.data.list;
                            delete a[o], n.setData({
                                list: a
                            });
                        }
                    }
                }) : a.cancel && console.log("用户点击取消");
            }
        });
    },
    to_shop: function(t) {
        wx.navigateTo({
            url: "../service/index"
        });
    },
    onLoad: function(t) {
        var n = this;
        a.config(n), a.theme(n), n.getData();
    },
    onReady: function() {},
    onShow: function() {
        a.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    getData: function() {
        var a = this;
        t.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "coupon",
                curr: a.data.curr
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var n = t.data;
                "" != n.data && a.setData({
                    list: n.data
                });
            }
        });
    }
});