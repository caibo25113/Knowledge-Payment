var a = getApp(), t = require("../common/common.js"), e = 1, n = !1;

Page({
    data: {
        pagePath: "../mall/mall",
        curr: -1,
        tagList1: [ "全部", "拼团", "限时抢购", "接龙团" ],
        tagCurr1: 0,
        list: []
    },
    tagChange1: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.tagCurr1 && (t.setData({
            tagCurr1: e
        }), t.getData(!0));
    },
    tab: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.curr && (t.setData({
            curr: e
        }), t.getData(!0));
    },
    onLoad: function(e) {
        var n = this;
        t.config(n), t.theme(n), "" != e.type && null != e.type && n.setData({
            tagCurr1: e.type
        }), a.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "service_class",
                type: 3
            },
            showLoading: !1,
            success: function(a) {
                var t = a.data;
                "" != t.data && n.setData({
                    pclass: t.data
                });
            }
        }), n.getData(!0);
    },
    onReady: function() {},
    onShow: function() {
        t.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    onShareAppMessage: function() {
        var t = this, e = "/xc_train/pages/mall/mall";
        return e = escape(e), {
            title: t.data.config.title,
            path: "/xc_train/pages/base/base?&share=" + e + "&share_id=" + a.userinfo.id,
            success: function(a) {
                console.log(a);
            },
            fail: function(a) {
                console.log(a);
            }
        };
    },
    getData: function(t) {
        var s = this;
        if (t && (e = 1, n = !1, s.setData({
            list: []
        })), !n) {
            var r = {
                op: "mall",
                page: e,
                pagesize: 20
            };
            -1 != s.data.curr && (r.cid = s.data.pclass[s.data.curr].id), 0 != s.data.tagCurr1 && (r.type = s.data.tagCurr1 + 1), 
            a.util.request({
                url: "entry/wxapp/service",
                data: r,
                success: function(a) {
                    var t = a.data;
                    wx.stopPullDownRefresh(), "" != t.data ? (e += 1, s.setData({
                        list: s.data.list.concat(t.data)
                    })) : n = !0;
                }
            });
        }
    }
});