var t = getApp(), a = require("../common/common.js"), e = 1, n = !1;

Page({
    data: {
        list: []
    },
    code: function(t) {
        var e = this, n = t.currentTarget.dataset.index;
        a.createQrCode(e.data.list[n].code, "mycanvas", .426666), e.setData({
            shadow: !0,
            menu: !0
        });
    },
    menu_close: function() {
        this.setData({
            menu: !1,
            shadow: !1
        });
    },
    onLoad: function(t) {
        var e = this;
        a.config(e), a.theme(e), e.getData(!0);
    },
    onReady: function() {},
    onShow: function() {
        a.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var o = this;
        a && (e = 1, n = !1, o.setData({
            list: []
        })), n || t.util.request({
            url: "entry/wxapp/user",
            data: {
                op: "prize",
                page: e,
                pagesize: 20
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var a = t.data;
                "" != a.data ? (e += 1, o.setData({
                    list: o.data.list.concat(a.data)
                })) : n = !0;
            }
        });
    }
});