function t(t) {
    var t = t, e = new Object();
    if (-1 != t.indexOf("?")) for (var n = t.substr(1).split("&"), a = 0; a < n.length; a++) e[n[a].split("=")[0]] = unescape(n[a].split("=")[1]);
    return e;
}

var e = getApp(), n = require("../../../wxParse/wxParse.js"), a = require("../common/common.js");

Page({
    data: {},
    onLoad: function(i) {
        var o = this;
        a.config(o, e), a.theme(o, e);
        var s = t(unescape(i.url));
        "" != s.id && null != s.id && e.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "article",
                id: s.id
            },
            success: function(t) {
                var e = t.data;
                if ("" != e.data && (o.setData({
                    list: e.data,
                    url: unescape(i.url)
                }), 2 == e.data.link_type)) {
                    var a = e.data.content;
                    n.wxParse("content", "html", a, o, 5);
                }
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        wx.stopPullDownRefresh();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = this, n = "/xc_train/pages/about/link?&url=" + escape(t.data.url);
        return n = escape(n), {
            title: t.data.list.title + "-" + t.data.config.title,
            path: "/xc_train/pages/base/base?&share=" + n + "&share_id=" + e.userinfo.id,
            success: function(t) {
                console.log(t);
            },
            fail: function(t) {
                console.log(t);
            }
        };
    }
});