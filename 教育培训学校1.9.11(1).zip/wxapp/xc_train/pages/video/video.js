var a = getApp(), t = require("../common/common.js");

Page({
    data: {
        curr: -1,
        pagePath: "/xc_train/pages/video/video",
        page: 1,
        pagesize: 20,
        isbottom: !1
    },
    tab: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.curr && (t.setData({
            curr: e
        }), t.getData(!0));
    },
    onLoad: function(e) {
        var o = this;
        t.config(o), t.theme(o), a.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "video_class"
            },
            showLoading: !1,
            success: function(a) {
                var t = a.data;
                "" != t.data && o.setData({
                    pclass: t.data
                });
            }
        }), o.getData(!0);
    },
    onReady: function() {},
    onShow: function() {
        t.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(t) {
        var e = this;
        if (t && e.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), !e.data.isbottom) {
            var o = {
                op: "video",
                page: e.data.page,
                pagesize: e.data.pagesize
            };
            -1 != e.data.curr && (o.cid = e.data.pclass[e.data.curr].id), a.util.request({
                url: "entry/wxapp/service",
                data: o,
                success: function(a) {
                    var t = a.data;
                    wx.stopPullDownRefresh(), "" != t.data ? e.setData({
                        list: t.data,
                        page: e.data.page + 1
                    }) : e.setData({
                        isbottom: !0
                    });
                }
            });
        }
    }
});