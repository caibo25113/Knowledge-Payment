var t = getApp(), a = require("../common/common.js");

Page({
    data: {
        pagePath: "../contact/contact"
    },
    call: function() {
        var t = this.data.map;
        wx.makePhoneCall({
            phoneNumber: t.content.mobile
        });
    },
    map: function() {
        var t = this.data.map;
        wx.openLocation({
            latitude: parseFloat(t.content.latitude),
            longitude: parseFloat(t.content.longitude),
            name: t.content.address,
            address: t.content.address,
            scale: 28
        });
    },
    onLoad: function(t) {
        var n = this;
        a.config(n), a.theme(n), n.getData();
    },
    onReady: function() {},
    onShow: function() {
        a.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    getData: function() {
        var a = this;
        t.util.request({
            url: "entry/wxapp/user",
            data: {
                op: "map"
            },
            success: function(t) {
                var n = t.data;
                "" != n.data && (wx.stopPullDownRefresh(), a.setData({
                    map: n.data
                }));
            }
        });
    }
});