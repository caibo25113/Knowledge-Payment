function t(t) {
    a = setInterval(function() {
        for (var a = t.data.list, n = 0; n < a.length; n++) a[n].fail > 0 && (a[n].fail = a[n].fail - 1, 
        a[n].hour = parseInt(a[n].fail / 3600), a[n].min = parseInt(a[n].fail % 3600 / 60), 
        a[n].second = a[n].fail % 60);
        t.setData({
            list: a
        });
    }, 1e3);
}

var a, n = getApp(), e = require("../common/common.js"), i = 1, o = !1;

Page({
    data: {
        list: []
    },
    onLoad: function(t) {
        var a = this;
        e.config(a), e.theme(a), a.getData(!0);
    },
    onReady: function() {},
    onShow: function() {
        e.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(e) {
        var s = this;
        e && (i = 1, o = !1, s.setData({
            list: []
        })), o || (clearInterval(a), n.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "cut_user",
                page: i,
                pagesize: 20
            },
            success: function(a) {
                var n = a.data;
                wx.stopPullDownRefresh(), "" != n.data ? (i += 1, s.setData({
                    list: s.data.list.concat(n.data)
                }), t(s)) : o = !0;
            }
        }));
    }
});