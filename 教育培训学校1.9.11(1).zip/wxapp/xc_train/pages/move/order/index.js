var t = getApp(), a = require("../../common/common.js"), e = 1, n = !1;

Page({
    data: {
        tab: [ "全部", "待参与", "已完成", "退款" ],
        tabCurr: 0,
        code: ""
    },
    tabChange: function(t) {
        var a = this, e = t.currentTarget.id;
        e != a.data.tabCurr && (a.setData({
            tabCurr: e
        }), a.getData(!0));
    },
    order_refund: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        a.setData({
            order_index: e,
            menu2: !0,
            shadow2: !0
        });
    },
    menu_close: function() {
        this.setData({
            menu2: !1,
            shadow2: !1
        });
    },
    input: function(t) {
        this.setData({
            content: t.detail.value
        });
    },
    menu_btn: function() {
        var a = this, e = a.data.content;
        "" != e && null != e ? t.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "mall_tui",
                id: a.data.list[a.data.order_index].id,
                content: a.data.content
            },
            success: function(t) {
                if ("" != t.data.data) {
                    wx.showToast({
                        title: "提交成功",
                        icon: "success",
                        duration: 2e3
                    });
                    var e = a.data.list;
                    e[a.data.order_index].status = 2, a.setData({
                        list: e,
                        content: "",
                        menu2: !1,
                        shadow2: !1
                    });
                }
            }
        }) : wx.showModal({
            title: "提示",
            content: "请输入退款原因"
        });
    },
    order_code: function(a) {
        var e = this, n = a.currentTarget.dataset.index;
        t.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "move_order_code",
                id: e.data.list[n].id
            },
            success: function(t) {
                var a = t.data;
                "" != a.data && e.setData({
                    code: a.data.code,
                    showhb: !0
                });
            }
        });
    },
    closehb: function() {
        this.setData({
            showhb: !1
        });
    },
    dlimg: function() {
        var t = this;
        a.downloadFile(t.data.code);
    },
    onLoad: function(t) {
        var e = this;
        a.config(e), a.theme(e), e.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var o = this;
        a && (e = 1, n = !1, o.setData({
            list: []
        })), n || t.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "move_order",
                page: e,
                pagesize: 20,
                curr: o.data.tabCurr
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var a = t.data;
                "" != a.data ? (o.setData({
                    list: o.data.list.concat(a.data)
                }), e += 1) : n = !0;
            }
        });
    }
});