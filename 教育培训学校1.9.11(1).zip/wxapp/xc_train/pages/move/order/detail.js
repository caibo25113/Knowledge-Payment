var t, a = getApp(), o = require("../../common/common.js");

Page({
    data: {},
    map: function() {
        var t = this.data.list.store_data;
        wx.openLocation({
            name: t.name,
            address: t.address,
            latitude: parseFloat(t.latitude),
            longitude: parseFloat(t.longitude),
            scale: 18
        });
    },
    onLoad: function(a) {
        var e = this;
        o.config(e), o.theme(e), t = a.id, e.getData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    getData: function() {
        var e = this;
        a.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "move_order_detail",
                id: t
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var a = t.data;
                "" != a.data && (e.setData({
                    list: a.data
                }), o.createQrCode(a.data.out_trade_no, "mycanvas", .427));
            }
        });
    }
});