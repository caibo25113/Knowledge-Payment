function a(a) {
    e = setInterval(function() {
        var t = a.data.fail;
        if (t > 0) {
            t -= 1;
            var n = [ parseInt(t / 86400), parseInt(t % 86400 / 3600), parseInt(t % 3600 / 60), t % 60 ];
            a.setData({
                fail: t,
                times: n
            });
        } else {
            var i = a.data.list;
            i.end = 1, clearInterval(e), a.setData({
                fail: 0,
                times: [ 0, 0, 0, 0 ],
                list: i
            });
        }
    }, 1e3);
}

var t, e, n = getApp(), i = require("../../common/common.js"), r = require("../../../../wxParse/wxParse.js"), o = 1, s = !1;

Page({
    data: {
        nav: [ "活动详情", "组别", "报名列表" ],
        curr: 0,
        fail: 0,
        times: [ 0, 0, 0, 0 ],
        order: []
    },
    tab: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.curr && t.setData({
            curr: e
        });
    },
    service_choose: function(a) {
        var t = this, e = t.data.list, n = a.currentTarget.dataset.index;
        e.format[n].choose = !e.format[n].choose, t.setData({
            list: e
        });
    },
    submit: function() {
        var a = [], e = this.data.list.format;
        if ("" != e && null != e) for (var n = 0; n < e.length; n++) e[n].choose && a.push(e[n].name);
        a.length > 0 ? wx.navigateTo({
            url: "../pay/index?&id=" + t + "&data=" + a.join(",")
        }) : wx.showModal({
            title: "提示",
            content: "请选择组别",
            showCancel: !1
        });
    },
    onLoad: function(a) {
        var e = this;
        i.config(e), i.theme(e), t = a.id, e.getData(), e.getOrder();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {
        var a = this;
        2 == a.data.curr && a.getOrder();
    },
    onShareAppMessage: function() {
        var a = this, t = "/xc_train/pages/move/detail/index";
        return t = escape(t), {
            title: a.data.config.title + "-" + a.data.list.name,
            path: "/xc_train/pages/base/base?&share=" + t + "&share_id=" + n.userinfo.id,
            success: function(a) {
                console.log(a);
            },
            fail: function(a) {
                console.log(a);
            }
        };
    },
    getData: function() {
        var i = this;
        n.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "move_detail",
                id: t
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var n = t.data;
                if ("" != n.data) {
                    if (i.setData({
                        list: n.data
                    }), "" != n.data.content && null != n.data.content) r.wxParse("article", "html", n.data.content, i, 0);
                    clearInterval(e), -1 == n.data.end && (i.setData({
                        fail: n.data.fail
                    }), a(i));
                }
            }
        });
    },
    getOrder: function() {
        var a = this;
        s || n.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "move_detail_order",
                page: o,
                pagesize: 20
            },
            success: function(t) {
                var e = t.data;
                "" != e.data ? (a.setData({
                    order: a.data.order.concat(e.data)
                }), o += 1) : s = !0;
            }
        });
    }
});