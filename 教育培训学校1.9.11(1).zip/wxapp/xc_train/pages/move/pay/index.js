function t(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

function e(t, e) {
    t.appId;
    var a = t.timeStamp.toString(), n = t.package, o = t.nonceStr, r = t.paySign.toUpperCase();
    t.out_trade_no;
    wx.requestPayment({
        timeStamp: a,
        nonceStr: o,
        package: n,
        signType: "MD5",
        paySign: r,
        success: function(t) {
            wx.showToast({
                title: "支付成功",
                icon: "success",
                duration: 2e3
            }), setTimeout(function() {
                wx.redirectTo({
                    url: "../order/index"
                });
            }, 2e3);
        }
    });
}

var a, n, o = getApp(), r = require("../../common/common.js");

Page({
    data: {
        amount: 0,
        agree: !0,
        agree_on: !1
    },
    member_up: function(t) {
        var e = this, a = e.data.xc, n = t.currentTarget.dataset.index;
        a.list[n].member++, e.setData({
            xc: a
        }), e.getAmount();
    },
    member_down: function(t) {
        var e = this, a = e.data.xc, n = t.currentTarget.dataset.index;
        a.list[n].member > 1 && (a.list[n].member--, e.setData({
            xc: a
        }), e.getAmount());
    },
    member_input: function(t) {
        var e = this, a = t.detail.value, n = t.currentTarget.dataset.index, o = e.data.xc;
        a > 0 || (a = 1), o.list[n].member = a, e.setData({
            xc: o
        }), e.getAmount();
    },
    input: function(e) {
        var a = this, n = e.currentTarget.dataset.name;
        a.setData(t({}, n, e.detail.value));
    },
    agree_change: function() {
        var t = this;
        t.setData({
            agree: !t.data.agree
        });
    },
    agree_on_change: function() {
        var t = this;
        t.setData({
            agree_on: !t.data.agree_on
        });
    },
    submit: function(t) {
        var n = this;
        if (!n.data.agree) return wx.showModal({
            title: "提示",
            content: "请同意",
            showCancel: !1
        }), !1;
        if ("" == n.data.name || null == n.data.name) return wx.showModal({
            title: "提示",
            content: "请输入家长姓名",
            showCancel: !1
        }), !1;
        if ("" == n.data.mobile || null == n.data.mobile) return wx.showModal({
            title: "提示",
            content: "请输入手机号",
            showCancel: !1
        }), !1;
        if (!/^[1][0-9]{10}$/.test(n.data.mobile)) return wx.showModal({
            title: "提示",
            content: "请输入正确的手机号",
            showCancel: !1
        }), !1;
        var r = {
            id: a,
            data: JSON.stringify(n.data.xc.list),
            name: n.data.name,
            mobile: n.data.mobile,
            form_id: t.detail.formId
        };
        o.util.request({
            url: "entry/wxapp/moveorder",
            data: r,
            success: function(t) {
                wx.stopPullDownRefresh();
                var a = t.data;
                "" != a.data && (1 == a.data.status ? "" != a.data.errno && null != a.data.errno ? wx.showModal({
                    title: "错误",
                    content: a.data.message,
                    showCancel: !1
                }) : e(a.data) : 2 == a.data.status && (wx.showToast({
                    title: "支付成功",
                    icon: "success",
                    duration: 2e3
                }), setTimeout(function() {
                    wx.redirectTo({
                        url: "../order/index"
                    });
                }, 2e3)));
            }
        });
    },
    onLoad: function(t) {
        var e = this;
        r.config(e), r.theme(e), a = t.id, n = t.data, e.getData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    getData: function() {
        var t = this;
        o.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "move_pay",
                id: a,
                data: n
            },
            success: function(e) {
                wx.stopPullDownRefresh();
                var a = e.data;
                "" != a.data && (t.setData({
                    xc: a.data
                }), t.getAmount());
            }
        });
    },
    getAmount: function() {
        for (var t = this, e = 0, a = t.data.xc.list, n = 0; n < a.length; n++) e = (parseFloat(e) + parseFloat(a[n].price) * parseInt(a[n].member)).toFixed(2);
        t.setData({
            amount: e
        });
    }
});