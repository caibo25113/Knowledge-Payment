var e = getApp(), a = require("../common/common.js");

Page({
    data: {
        pagePath: "/xc_train/pages/user/user",
        menu: [ {
            name: "报名记录",
            img: e.imageUrl + "user01.png",
            link: "../record/record?&order_type=1"
        }, {
            name: "预约记录",
            img: e.imageUrl + "user02.png",
            link: "../record/record?&order_type=2"
        }, {
            name: "我的奖品",
            img: e.imageUrl + "user07.png",
            link: "../prize/prize"
        }, {
            name: "我的订单",
            img: e.imageUrl + "user09.png",
            link: "../order/order"
        }, {
            name: "我的音频",
            img: e.imageUrl + "user10.png",
            link: "../audio/order"
        }, {
            name: "我的视频",
            img: e.imageUrl + "user11.png",
            link: "../video/order"
        }, {
            name: "我的礼包",
            img: e.imageUrl + "user13.png",
            link: "../line/order/index"
        }, {
            name: "我的团购",
            img: e.imageUrl + "user14.png",
            link: "../group/order/index"
        }, {
            name: "我报名的活动",
            img: e.imageUrl + "user15.png",
            link: "../move/order/index"
        }, {
            name: "接龙团订单",
            img: e.imageUrl + "user16.png",
            link: "../team/order/index"
        }, {
            name: "团长中心",
            img: e.imageUrl + "user17.png",
            link: "../team/user/index"
        }, {
            name: "优惠券",
            img: e.imageUrl + "user03.png",
            link: "../coupon/coupon"
        }, {
            name: "我的地址",
            img: e.imageUrl + "user08.png",
            link: "../address/address"
        } ],
        images: {
            arrow: e.imageUrl + "arrow.png"
        }
    },
    call: function() {
        var e = this.data.map;
        wx.makePhoneCall({
            phoneNumber: e.mobile
        });
    },
    map: function() {
        var e = this.data.map;
        wx.openLocation({
            latitude: parseFloat(e.latitude),
            longitude: parseFloat(e.longitude),
            name: e.address,
            address: e.address,
            scale: 28
        });
    },
    onLoad: function(e) {
        var n = this;
        a.config(n), a.theme(n), n.getData(), wx.getSetting({
            success: function(e) {
                e.authSetting["scope.userInfo"] && wx.getUserInfo({
                    success: function(e) {
                        n.setData({
                            userInfo: e
                        });
                    }
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        a.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    getData: function() {
        var a = this;
        e.util.request({
            url: "entry/wxapp/user",
            data: {
                op: "user"
            },
            success: function(e) {
                wx.stopPullDownRefresh();
                var n = e.data;
                "" != n.data && ("" != n.data.map && null != n.data.map && a.setData({
                    map: n.data.map
                }), "" != n.data.user && null != n.data.user && a.setData({
                    user: n.data.user
                }), "" != n.data.share && null != n.data.share && a.setData({
                    share: n.data.share
                }));
            }
        });
    }
});