var e = getApp(), a = require("../common/common.js");

Page({
    data: {},
    onLoad: function(i) {
        var n = this;
        "" != i.share_id && null != i.share_id && (e.share = i.share_id), a.login(n), wx.getSystemInfo({
            success: function(a) {
                -1 != a.system.indexOf("Android") ? e.mobile = 2 : -1 != a.system.indexOf("iOS") && (e.mobile = 1);
            }
        }), e.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "base"
            },
            showLoading: !1,
            success: function(a) {
                var n = a.data;
                if ("" != n.data && ("" != n.data.xc_img && null != n.data.xc_img && (e.xc_img = n.data.xc_img), 
                "" != n.data.config && null != n.data.config && (e.config = n.data.config), "" != n.data.theme && null != n.data.theme && (e.theme = n.data.theme), 
                "" != n.data.closed && null != n.data.closed && wx.redirectTo({
                    url: "../closed/closed"
                })), "" != e.service && null != e.service) wx.redirectTo({
                    url: "../service/detail?&id=" + e.service
                }); else if ("" != e.audio && null != e.audio) wx.redirectTo({
                    url: "../audio/detail?&id=" + e.audio
                }); else if ("" != i.share && null != i.share) {
                    var o = unescape(i.share);
                    wx.redirectTo({
                        url: o
                    });
                } else wx.redirectTo({
                    url: "../index/index"
                });
            }
        }), e.util.request({
            url: "entry/wxapp/grouprefund",
            method: "POST",
            showLoading: !1
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});