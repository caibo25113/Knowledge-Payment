function t(t) {
    var e = this, o = getApp();
    "" != t.detail.userInfo && null != t.detail.userInfo && (o.util.getUserInfo(function(t) {
        var n = {};
        "" != t.wxInfo && null != t.wxInfo ? (n = t.wxInfo).op = "userinfo" : n.op = "userinfo", 
        "" != o.share && null != o.share && (n.share = o.share), o.util.request({
            url: "entry/wxapp/index",
            showLoading: !1,
            data: n,
            success: function(t) {
                var n = t.data;
                "" != n.data && (o.userinfo = n.data, e.setData({
                    userInfo: n.data,
                    user: n.data
                }));
            }
        });
    }, t.detail), console.log(t));
}

function e(t) {
    n = setInterval(function() {
        a.audio_status || (clearInterval(n), t.setData({
            audio_status: !1
        }));
    }, 1e3);
}

function o() {
    var t = getCurrentPages();
    return t[t.length - 1].route;
}

var n, a = getApp();

module.exports = {
    config: function(e) {
        var o = [ {
            pagePath: "/xc_train/pages/index/index",
            text: "主页",
            iconPath: "/xc_train/resource/bottom01.png",
            selectedIconPath: "/xc_train/resource/bottom001.png",
            status: 1
        }, {
            pagePath: "/xc_train/pages/active/list",
            text: "优惠活动",
            iconPath: "/xc_train/resource/bottom02.png",
            selectedIconPath: "/xc_train/resource/bottom002.png",
            status: 1
        }, {
            pagePath: "/xc_train/pages/video/video",
            text: "视频",
            iconPath: "/xc_train/resource/bottom04.png",
            selectedIconPath: "/xc_train/resource/bottom004.png",
            status: 1
        }, {
            pagePath: "/xc_train/pages/user/user",
            text: "我的",
            iconPath: "/xc_train/resource/bottom03.png",
            selectedIconPath: "/xc_train/resource/bottom003.png",
            status: 1
        }, {
            pagePath: "",
            text: "",
            iconPath: "",
            selectedIconPath: "",
            status: -1
        } ], n = "";
        if ("" != a.config && null != a.config && (wx.setNavigationBarTitle({
            title: a.config.content.title
        }), "" != (n = a.config.content).footer && null != n.footer)) for (r = 0; r < n.footer.length; r++) "" != n.footer[r].text && null != n.footer[r].text && (o[r].text = n.footer[r].text), 
        "" != n.footer[r].icon && null != n.footer[r].icon && (o[r].iconPath = n.footer[r].icon), 
        "" != n.footer[r].select && null != n.footer[r].select && (o[r].selectedIconPath = n.footer[r].select), 
        "" != n.footer[r].link && null != n.footer[r].link && (o[r].pagePath = n.footer[r].link), 
        "" != n.footer[r].status && null != n.footer[r].status && (o[r].status = n.footer[r].status);
        for (var r = 0; r < o.length; r++) e.data.pagePath == o[r].pagePath && e.setData({
            footerCurr: r + 1
        });
        e.updateUserInfo = t, e.setData({
            footer: o,
            config: n,
            system_mobile: a.mobile,
            xc_img: a.xc_img
        });
    },
    theme: function(t) {
        var e = {
            name: "theme1",
            color: "#5fcceb",
            icon: [ "/xc_train/resource/icon01.png", "/xc_train/resource/class01.png", a.xc_img.class01, "/xc_train/resource/class03.png", "/xc_train/resource/contact01.png", "/xc_train/resource/contact02.png", "/xc_train/resource/contact03.png", "/xc_train/resource/contact04.png", "/xc_train/resource/manage01.png" ]
        };
        if ("" != a.theme && null != a.theme) {
            var o = a.theme.content;
            if (2 == o.theme && (e.name = "theme" + o.theme, e.color = o.color, "" != o.icon && null != o.icon)) {
                for (var n = 0; n < o.icon.length; n++) "" != o.icon[n] && null != o.icon[n] && (e.icon[n] = o.icon[n]);
                wx.setNavigationBarColor({
                    frontColor: "#ffffff",
                    backgroundColor: e.color,
                    animation: {
                        duration: 400,
                        timingFunc: "easeIn"
                    }
                });
            }
        }
        t.setData({
            theme: e
        });
    },
    login: function(t, e) {
        a.util.getUserInfo(function(t) {
            var e = {};
            "" != t.wxInfo && null != t.wxInfo ? (e = t.wxInfo).op = "userinfo" : e.op = "userinfo", 
            "" != a.share && null != a.share && (e.share = a.share), a.util.request({
                url: "entry/wxapp/index",
                showLoading: !1,
                data: e,
                success: function(t) {
                    var e = t.data;
                    "" != e.data && (a.userinfo = e.data);
                }
            });
        });
    },
    updateUserInfo: t,
    audio_end: function(t) {
        var r = o();
        clearInterval(n), "xc_train/pages/audio/audio" != r && "xc_train/pages/audio/detail" != r && "" != a.innerAudioContext.src && null != a.innerAudioContext.src && "" != a.audio_Id && null != a.audio_Id ? (t.setData({
            audio_status: a.audio_status,
            audio_on: a.audio_on
        }), e(t)) : (a.audio_status = !1, t.setData({
            audio_status: !1
        }));
    },
    formCheck: function(t, e, o) {
        for (var n in t) for (var a = 0; a < e.length; a++) if (n == e[a].name) {
            if (e[a].required && ("" == t[n] || null == t[n])) return wx.showModal({
                title: "提示",
                content: e[a].required_msg
            }), !1;
            if (e[a].tel && !/^[1][0-9]{10}$/.test(t[n])) return wx.showModal({
                title: "提示",
                content: e[a].tel_msg
            }), !1;
            if (e[a].gt && parseFloat(t[n]) < parseFloat(e[a].gt)) return wx.showModal({
                title: "提示",
                content: e[a].gt_msg
            }), !1;
            if (e[a].lt && parseFloat(t[n]) > parseFloat(e[a].lt)) return wx.showModal({
                title: "提示",
                content: e[a].lt_msg
            }), !1;
        }
        return !0;
    },
    createQrCode: function(t, e, o) {
        var n = {};
        try {
            var o = o, r = wx.getSystemInfoSync().windowWidth * o, i = r;
            n.w = r, n.h = i;
        } catch (t) {
            console.log("获取设备信息失败" + t);
        }
        a.qr.qrApi.draw(t, e, n.w, n.h);
    },
    downloadFile: function(t) {
        wx.showLoading({
            title: "保存中"
        }), wx.downloadFile({
            url: t,
            success: function(t) {
                wx.saveImageToPhotosAlbum({
                    filePath: t.tempFilePath,
                    success: function(t) {
                        wx.hideLoading(), wx.showToast({
                            title: "保存成功",
                            icon: "success",
                            duration: 2e3
                        });
                    },
                    fail: function(t) {
                        wx.hideLoading(), wx.showToast({
                            title: "保存失败",
                            icon: "success",
                            duration: 2e3
                        });
                    }
                });
            }
        });
    }
};