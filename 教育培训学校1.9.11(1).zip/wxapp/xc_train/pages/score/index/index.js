var a = getApp(), t = require("../../common/common.js"), e = 1, c = !1;

Page({
    data: {
        list: [],
        score_check: !1
    },
    score_check: function() {
        var t = this;
        -1 == t.data.check_data.check_status && a.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "score_check"
            },
            success: function(a) {
                var e = a.data;
                if ("" != e.data) {
                    var c = t.data.user, s = t.data.check_data;
                    s.check_status = 1, c.score = parseInt(c.score) + e.data.score, t.setData({
                        score: e.data.score,
                        check_data: s,
                        score_check: !0,
                        user: c
                    });
                }
            }
        });
    },
    score_close: function() {
        this.setData({
            score_check: !1
        });
    },
    onLoad: function(a) {
        var e = this;
        t.config(e), t.theme(e), e.getData(), e.getMall(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        var a = this;
        a.getData(), a.getMall(!0);
    },
    onReachBottom: function() {
        this.getMall(!1);
    },
    getData: function() {
        var t = this;
        a.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "score_index"
            },
            success: function(a) {
                var e = a.data;
                "" != e.data && ("" != e.data.user && null != e.data.user && t.setData({
                    user: e.data.user
                }), "" != e.data.config && null != e.data.config && t.setData({
                    xc_config: e.data.config
                }), "" != e.data.check_data && null != e.data.check_data && t.setData({
                    check_data: e.data.check_data
                }));
            }
        });
    },
    getMall: function(t) {
        var s = this;
        t && (e = 1, c = !1, s.setData({
            list: []
        })), c || a.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "score_mall",
                page: e,
                pagesize: 20
            },
            success: function(a) {
                wx.stopPullDownRefresh();
                var t = a.data;
                "" != t.data ? (e += 1, s.setData({
                    list: s.data.list.concat(t.data)
                })) : c = !0;
            }
        });
    }
});