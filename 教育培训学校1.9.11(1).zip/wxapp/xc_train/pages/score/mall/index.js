var a = getApp(), t = require("../../common/common.js"), e = require("../../../../wxParse/wxParse.js"), n = "";

Page({
    data: {
        numbervalue: 1
    },
    numPlus: function() {
        var a = this, t = a.data.list, e = parseInt(a.data.numbervalue) + 1;
        e <= parseInt(t.kucun) && a.setData({
            numbervalue: e
        });
    },
    numMinus: function() {
        var a = this, t = parseInt(a.data.numbervalue) - 1;
        t >= 1 && a.setData({
            numbervalue: t
        });
    },
    valChange: function(a) {
        var t = this, e = a.detail.value, n = t.data.list;
        e >= 1 && e <= parseInt(n.kucun) || (e = 1), t.setData({
            numbervalue: e
        });
    },
    submit: function() {
        var a = this;
        wx.navigateTo({
            url: "../mall/order?&id=" + n + "&member=" + a.data.numbervalue
        });
    },
    onLoad: function(a) {
        var e = this;
        t.config(e), t.theme(e), n = a.id, e.getData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = this, e = "/xc_train/pages/score/mall/index";
        return e = escape(e), {
            title: t.data.config.title + "-" + t.data.list.name,
            path: "/xc_train/pages/base/base?&share=" + e + "&share_id=" + a.userinfo.id,
            success: function(a) {
                console.log(a);
            },
            fail: function(a) {
                console.log(a);
            }
        };
    },
    getData: function() {
        var t = this;
        a.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "score_detail",
                id: n
            },
            success: function(a) {
                var n = a.data;
                if (wx.stopPullDownRefresh(), "" != n.data && (t.setData({
                    list: n.data
                }), "" != n.data.content && null != n.data.content)) e.wxParse("article", "html", n.data.content, t, 0);
            }
        });
    }
});