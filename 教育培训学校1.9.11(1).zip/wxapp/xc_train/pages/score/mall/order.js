var t = getApp(), e = require("../../common/common.js"), a = "", n = "";

Page({
    data: {
        pei_type: 1
    },
    input: function(t) {
        this.setData({
            input: t.detail.value
        });
    },
    pei_change: function(t) {
        var e = this, a = t.currentTarget.dataset.index;
        a != e.data.pei_type && e.setData({
            pei_type: a
        });
    },
    store_on: function() {
        this.setData({
            store_page: !0
        });
    },
    store_close: function() {
        this.setData({
            store_page: !1
        });
    },
    store_choose: function(t) {
        var e = this, a = t.currentTarget.dataset.index, n = e.data.store;
        e.setData({
            store_page: !1,
            store_id: n[a].id,
            store_name: n[a].name
        });
    },
    submit: function(e) {
        var a = this;
        if ("" == a.data.address || null == a.data.address) return wx.showModal({
            title: "错误",
            content: "请完善用户信息"
        }), !1;
        if ("" == a.data.store_id || null == a.data.store_id) return wx.showModal({
            title: "错误",
            content: "请选择提货校区"
        }), !1;
        var n = {
            form_id: e.detail.formId,
            store: a.data.store_id,
            id: a.data.id,
            member: a.data.member,
            pei_type: a.data.pei_type
        };
        "" != a.data.content && null != a.data.content && (n.content = a.data.content), 
        t.util.request({
            url: "entry/wxapp/scoreorder",
            data: n,
            success: function(t) {
                "" != t.data.data && (wx.showToast({
                    title: "兑换成功",
                    icon: "success",
                    duration: 2e3
                }), setTimeout(function() {
                    wx.redirectTo({
                        url: "../order/index"
                    });
                }, 2e3));
            }
        });
    },
    onLoad: function(t) {
        var o = this;
        e.config(o), e.theme(o), o.setData({
            id: t.id,
            member: t.member
        }), wx.getLocation({
            type: "wgs84",
            success: function(t) {
                a = t.latitude, n = t.longitude;
            },
            complete: function() {
                o.getData();
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    getData: function() {
        var e = this, o = {
            op: "score_pay",
            id: e.data.id,
            member: e.data.member
        };
        "" != a && null != n && (o.latitude = a, o.longitude = n), t.util.request({
            url: "entry/wxapp/index",
            data: o,
            success: function(t) {
                var a = t.data;
                wx.stopPullDownRefresh(), "" != a.data && ("" != a.data.map && null != a.data.map && e.setData({
                    address: a.data.map
                }), "" != a.data.service && null != a.data.service && e.setData({
                    service: a.data.service
                }), "" != a.data.store && null != a.data.store && e.setData({
                    store: a.data.store
                }));
            }
        });
    }
});