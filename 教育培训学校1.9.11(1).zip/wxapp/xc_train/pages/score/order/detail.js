var t, n = getApp(), o = require("../../common/common.js");

Page({
    data: {},
    onLoad: function(n) {
        var a = this;
        o.config(a), o.theme(a), t = n.id, a.getData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    getData: function() {
        var o = this;
        n.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "score_order_detail",
                id: t
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var n = t.data;
                "" != n.data && o.setData({
                    list: n.data
                });
            }
        });
    }
});