var t = getApp(), a = require("../../common/common.js"), n = 1, e = !1;

Page({
    data: {
        tab: [ "全部", "待核销", "已核销" ],
        tabCurr: 0,
        list: []
    },
    tabChange: function(t) {
        var a = this, n = t.currentTarget.id;
        n != a.data.tabCurr && (a.setData({
            tabCurr: n
        }), a.getData(!0));
    },
    shFunc: function(t) {
        var n = this, e = t.currentTarget.dataset.index, o = n.data.list;
        a.createQrCode(o[e].out_trade_no, "mycanvas", .4), n.setData({
            canshow: !0,
            menu: !0
        });
    },
    canshow: function() {
        this.setData({
            canshow: !1,
            menu: !1
        });
    },
    onLoad: function(t) {
        var n = this;
        a.config(n), a.theme(n), n.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var o = this;
        a && (n = 1, e = !1, o.setData({
            list: []
        })), e || t.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "score_order",
                page: n,
                pagesize: 20,
                curr: o.data.tabCurr
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var a = t.data;
                "" != a.data ? (n += 1, o.setData({
                    list: o.data.list.concat(a.data)
                })) : e = !0;
            }
        });
    }
});