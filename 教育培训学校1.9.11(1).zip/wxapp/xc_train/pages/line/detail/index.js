function t(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

function a(t, a) {
    t.appId;
    var e = t.timeStamp.toString(), s = t.package, n = t.nonceStr, i = t.paySign.toUpperCase();
    wx.requestPayment({
        timeStamp: e,
        nonceStr: n,
        package: s,
        signType: "MD5",
        paySign: i,
        success: function(t) {
            wx.showToast({
                title: "支付成功",
                icon: "success",
                duration: 2e3
            });
            var e = a.data.list;
            e.order = 1, self.setData({
                list: e
            });
        },
        fail: function(t) {}
    });
}

function e(t) {
    var a = t.data.name, e = t.data.mobile, s = !0, n = "";
    "" != a && null != a || (s = !1, n = "请输入姓名"), "" != e && null != e || (s = !1, 
    n = "请输入手机号"), /^(((13[0-9]{1})|(14[0-9]{1})|(17[0-9]{1})|(15[0-3]{1})|(15[5-9]{1})|(18[0-9]{1}))+\d{8})$/.test(e) || (s = !1, 
    n = "请输入正确的手机号"), t.setData({
        submit: s
    }), s || wx.showModal({
        title: "提示",
        content: n,
        showCancel: !1
    });
}

var s, n = getApp(), i = require("../../common/common.js"), o = require("../../../../wxParse/wxParse.js");

Page((s = {
    data: {
        curr: 1,
        page: 1,
        pagesize: 20,
        isbottim: !1,
        tui: [],
        submit: !1
    },
    zan: function() {
        var t = this;
        -1 == t.data.list.zan_user && n.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "line_zan",
                id: t.data.id
            },
            success: function(a) {
                if ("" != a.data.data) {
                    wx.showToast({
                        title: "点赞成功",
                        icon: "success",
                        duration: 2e3
                    });
                    var e = t.data.list;
                    e.zan_user = 1, e.zan = parseInt(e.zan) + 1, t.setData({
                        list: e
                    });
                }
            }
        });
    },
    tab: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        e != a.data.curr && a.setData({
            curr: e
        });
    },
    input: function(t) {
        this.setData({
            content: t.detail.value
        });
    },
    discuss_on: function() {
        var t = this, a = t.data.content;
        "" != a && null != a ? n.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "discuss_on",
                id: t.data.id,
                content: a,
                type: 4
            },
            success: function(a) {
                if ("" != a.data.data) {
                    wx.showToast({
                        title: "评论成功",
                        icon: "success",
                        duration: 2e3
                    });
                    var e = t.data.list;
                    e.discuss = parseInt(e.discuss) + 1, e.discuss_on = 1, t.setData({
                        content: "",
                        list: e
                    }), t.getDiscuss(!0);
                }
            }
        }) : wx.showModal({
            title: "错误",
            content: "评论内容不能为空",
            success: function(t) {
                t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
            }
        });
    }
}, t(s, "input", function(a) {
    var e = this, s = a.currentTarget.dataset.name;
    e.setData(t({}, s, a.detail.value));
}), t(s, "submit", function() {
    this.setData({
        menu: !0,
        shadow2: !0
    });
}), t(s, "menu_close", function() {
    this.setData({
        menu: !1,
        shadow2: !1
    });
}), t(s, "menu_submit", function(t) {
    var s = this;
    e(s), s.data.submit && n.util.request({
        url: "entry/wxapp/lineOrder",
        data: {
            id: s.data.id,
            name: s.data.name,
            mobile: s.data.mobile,
            form_id: t.detail.formId
        },
        success: function(t) {
            var e = t.data;
            if ("" != e.data) if (2 == e.data.status) {
                wx.showToast({
                    title: "支付成功",
                    icon: "success",
                    duration: 2e3
                });
                var n = s.data.list;
                n.order = 1, s.setData({
                    list: n
                });
            } else 1 == e.data.status && ("" != e.data.errno && null != e.data.errno ? wx.showModal({
                title: "错误",
                content: e.data.message,
                showCancel: !1
            }) : a(e.data, s));
        }
    });
}), t(s, "onLoad", function(t) {
    var a = this;
    i.config(a), i.theme(a), a.setData({
        id: t.id
    }), a.getData(), a.getDiscuss(!0);
}), t(s, "onReady", function() {}), t(s, "onShow", function() {}), t(s, "onHide", function() {}), 
t(s, "onUnload", function() {}), t(s, "onPullDownRefresh", function() {
    this.getData();
}), t(s, "onReachBottom", function() {
    var t = this;
    3 == t.data.curr && t.getDiscuss(!1);
}), t(s, "onShareAppMessage", function() {
    var t = this, a = "/xc_train/pages/line/detail/index?&id=" + t.data.id;
    return a = escape(a), {
        title: t.data.config.title + "-" + t.data.list.name,
        path: "/xc_train/pages/base/base?&share=" + a + "&share_id=" + n.userinfo.id,
        success: function(t) {
            console.log(t);
        },
        fail: function(t) {
            console.log(t);
        }
    };
}), t(s, "getData", function() {
    var t = this;
    n.util.request({
        url: "entry/wxapp/index",
        data: {
            op: "line_detail",
            id: t.data.id
        },
        success: function(a) {
            var e = a.data;
            if (wx.stopPullDownRefresh(), "" != e.data && (t.setData({
                list: e.data
            }), "" != e.data.content && null != e.data.content)) {
                var s = e.data.content;
                o.wxParse("content2", "html", s, t, 5);
            }
        }
    });
}), t(s, "getDiscuss", function(t) {
    var a = this;
    t && a.setData({
        page: 1,
        isbottim: !1,
        tui: []
    }), a.data.isbottim || n.util.request({
        url: "entry/wxapp/order",
        data: {
            op: "discuss",
            page: a.data.page,
            pagesize: a.data.pagesize,
            type: 4,
            id: a.data.id
        },
        success: function(t) {
            var e = t.data;
            wx.stopPullDownRefresh(), "" != e.data ? a.setData({
                tui: a.data.tui.concat(e.data),
                page: a.data.page + 1
            }) : a.setData({
                isbottim: !0
            });
        }
    });
}), s));