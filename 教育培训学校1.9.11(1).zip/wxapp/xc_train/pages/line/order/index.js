var t = getApp(), a = require("../../common/common.js"), o = 1, n = !1;

Page({
    data: {
        curr: 0,
        list: []
    },
    onLoad: function(t) {
        var o = this;
        a.config(o), a.theme(o), o.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var e = this;
        a && e.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), e.data.isbottom || t.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "line_order",
                page: o,
                pagesize: 20
            },
            success: function(t) {
                var a = t.data;
                wx.stopPullDownRefresh(), "" != a.data ? (o += 1, e.setData({
                    list: e.data.list.concat(a.data)
                })) : n = !0;
            }
        });
    }
});