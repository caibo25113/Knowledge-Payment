function t(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

function a(t) {
    n.util.request({
        url: "entry/wxapp/user",
        method: "POST",
        data: {
            op: "address"
        },
        success: function(a) {
            var e = a.data;
            wx.stopPullDownRefresh(), "" != e.data && t.setData({
                list: e.data
            });
        }
    });
}

function e(t) {
    var a = t.data.name, e = t.data.mobile, s = t.data.address, n = "", d = t.data.config, i = -1;
    "" != d.map_status && null != d.map_status && (i = d.map_status), 1 != i && ("" != s && null != s || (n = "请先定位")), 
    "" == e || null == e ? n = "请输入手机号码" : /^[1][0-9]{10}$/.test(e) || (n = "请输入正确的手机号码"), 
    "" != a && null != a || (n = "请输入您的姓名"), "" == n ? t.setData({
        submit: !0
    }) : wx.showModal({
        title: "错误",
        content: n
    });
}

var s = require("../common/common.js"), n = getApp();

Page({
    data: {
        change_id: -1,
        shwoLayer: !1,
        newsex: 1,
        submit: !1,
        can_load: !0
    },
    edit: function(t) {
        var a = this, e = t.currentTarget.dataset.index, s = a.data.list;
        a.setData({
            shwoLayer: !0,
            name: s[e].name,
            newsex: s[e].sex,
            mobile: s[e].mobile,
            address: s[e].address,
            content: s[e].content,
            latitude: s[e].latitude,
            longitude: s[e].longitude,
            change_id: s[e].id
        });
    },
    addressChange: function(t) {
        var a = this, e = t.detail.value, s = a.data.list;
        1 != s[e].status && n.util.request({
            url: "entry/wxapp/user",
            method: "POST",
            data: {
                op: "address_status",
                id: s[e].id
            },
            success: function(t) {
                if ("" != t.data.data) {
                    for (var n = 0; n < s.length; n++) s[n].status = -1;
                    s[e].status = 1, a.setData({
                        list: s
                    });
                }
            }
        });
    },
    deleteAddr: function(t) {
        var a = this, e = t.currentTarget.dataset.index, s = a.data.list;
        wx.showModal({
            title: "确认删除",
            content: "是否删除这条地址信息？",
            success: function(t) {
                t.confirm && (1 == s[e].status ? wx.showModal({
                    title: "错误",
                    content: "默认地址无法删除"
                }) : n.util.request({
                    url: "entry/wxapp/user",
                    method: "POST",
                    data: {
                        op: "address_del",
                        id: s[e].id
                    },
                    success: function(t) {
                        "" != t.data.data && (wx.showToast({
                            title: "删除成功",
                            icon: "success",
                            duration: 2e3
                        }), s.splice(e, 1), a.setData({
                            list: e
                        }));
                    }
                }));
            }
        });
    },
    mapping: function() {
        var t = this;
        wx.chooseLocation({
            success: function(a) {
                t.setData({
                    address: a.address,
                    latitude: a.latitude,
                    longitude: a.longitude
                });
            }
        });
    },
    sexSelect: function(t) {
        var a = this, e = t.currentTarget.id;
        a.setData({
            newsex: e
        });
    },
    showLayer: function() {
        this.setData({
            shwoLayer: !0
        });
    },
    closeLayer: function() {
        this.setData({
            shwoLayer: !1,
            name: "",
            newsex: 1,
            mobile: "",
            address: "",
            content: "",
            submit: !1,
            change_id: -1
        });
    },
    input: function(a) {
        var e = this, s = a.currentTarget.dataset.name, n = a.detail.value;
        e.setData(t({}, s, n));
    },
    submit: function() {
        var t = this;
        if (e(t), t.data.submit && t.data.can_load) {
            t.setData({
                can_load: !1,
                shwoLayer: !1
            });
            var s = {
                op: "address_edit",
                name: t.data.name,
                sex: t.data.newsex,
                mobile: t.data.mobile
            };
            "" != t.data.address && null != t.data.address && (s.address = t.data.address, s.latitude = t.data.latitude, 
            s.longitude = t.data.longitude), "" != t.data.content && null != t.data.content && (s.content = t.data.content), 
            -1 != t.data.change_id && (s.id = t.data.change_id), n.util.request({
                url: "entry/wxapp/user",
                method: "POST",
                data: s,
                success: function(e) {
                    var s = e.data;
                    t.setData({
                        can_load: !0,
                        name: "",
                        newsex: 1,
                        mobile: "",
                        address: "",
                        content: "",
                        submit: !1,
                        change_id: -1
                    }), "" != s.data && (wx.showToast({
                        title: "操作成功",
                        icon: "success",
                        duration: 2e3
                    }), a(t));
                }
            });
        }
    },
    onLoad: function(t) {
        var e = this;
        s.config(e), s.theme(e), a(e);
    },
    onReady: function() {},
    onShow: function() {
        s.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        wx.stopPullDownRefresh();
    },
    onReachBottom: function() {}
});