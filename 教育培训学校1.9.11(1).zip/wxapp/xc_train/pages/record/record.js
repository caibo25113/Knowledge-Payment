var t = getApp(), e = require("../common/common.js"), a = 1, o = !1;

Page({
    data: {
        list: []
    },
    code: function(t) {
        var a = this, o = t.currentTarget.dataset.index;
        e.createQrCode(a.data.list[o].out_trade_no, "mycanvas", .426666), a.setData({
            shadow: !0,
            menu: !0
        });
    },
    menu_close: function() {
        this.setData({
            menu: !1,
            shadow: !1,
            use_time: !1
        });
    },
    use_on: function(t) {
        var e = this, a = t.currentTarget.dataset.index;
        e.setData({
            shadow: !0,
            use_time: !0,
            index: a
        });
    },
    onLoad: function(t) {
        var a = this;
        e.config(a), e.theme(a), "" != t.order_type && "" != t.order_type && a.setData({
            order_type: t.order_type
        }), a.getData(!0);
    },
    onReady: function() {},
    onShow: function() {
        e.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(e) {
        var n = this;
        e && (a = 1, o = !1, n.setData({
            list: []
        })), o || t.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "order",
                page: a,
                pagesize: 20,
                order_type: n.data.order_type
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var e = t.data;
                "" != e.data ? (a += 1, n.setData({
                    list: n.data.list.concat(e.data)
                })) : o = !0;
            }
        });
    }
});