var t, a = getApp(), e = require("../../../wxParse/wxParse.js"), n = require("../common/common.js");

Page({
    data: {},
    zan: function(t) {
        var e = this, n = t.currentTarget.dataset.index, s = !0;
        1 == n ? 1 == e.data.list.is_student && (s = !1) : 2 == n && 1 == e.data.list.is_zan && (s = !1), 
        s && a.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "zan",
                id: e.data.list.id,
                status: n
            },
            success: function(t) {
                if ("" != t.data.data) {
                    wx.showToast({
                        title: "操作成功",
                        icon: "success",
                        duration: 2e3
                    });
                    var s = e.data.list;
                    if (1 == n) {
                        var i = {
                            avatar: a.userinfo.avatar
                        };
                        s.member.unshift(i), s.is_student = 1;
                    } else 2 == n && (s.is_zan = 1);
                    e.setData({
                        list: s
                    });
                }
            }
        });
    },
    onLoad: function(a) {
        var e = this;
        n.config(e), n.theme(e), t = a.id, e.getData();
    },
    onReady: function() {},
    onShow: function() {
        n.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = this, n = "/xc_train/pages/teacher/detail?&id=" + t;
        return n = escape(n), {
            title: e.data.config.title + "-" + e.data.list.name,
            path: "/xc_train/pages/base/base?&share=" + n + "&share_id=" + a.userinfo.id,
            success: function(t) {
                console.log(t);
            },
            fail: function(t) {
                console.log(t);
            }
        };
    },
    getData: function() {
        var n = this;
        a.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "teacher_detail",
                id: t
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var a = t.data;
                if ("" != a.data && (n.setData({
                    list: a.data
                }), 2 == a.data.content_type)) {
                    var s = a.data.content2;
                    e.wxParse("content", "html", s, n, 5);
                }
            }
        });
    }
});