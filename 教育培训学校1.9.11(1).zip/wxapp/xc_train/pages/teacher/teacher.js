var a = getApp(), t = require("../common/common.js"), e = 1, s = !1;

Page({
    data: {
        curr: -1,
        list: []
    },
    tab: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.curr && (t.setData({
            curr: e
        }), t.getData(!0));
    },
    onLoad: function(e) {
        var s = this;
        t.config(s), t.theme(s), a.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "service_class",
                type: 2
            },
            showLoading: !1,
            success: function(a) {
                var t = a.data;
                "" != t.data && s.setData({
                    pclass: t.data
                });
            }
        }), s.getData(!0);
    },
    onReady: function() {},
    onShow: function() {
        t.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    onShareAppMessage: function() {
        var t = this, e = "/xc_train/pages/teacher/teacher";
        return e = escape(e), {
            title: t.data.config.title + "-名师简介",
            path: "/xc_train/pages/base/base?&share=" + e + "&share_id=" + a.userinfo.id,
            success: function(a) {
                console.log(a);
            },
            fail: function(a) {
                console.log(a);
            }
        };
    },
    getData: function(t) {
        var n = this;
        if (t && (e = 1, s = !1, n.setData({
            list: []
        })), !s) {
            var i = {
                op: "teacher",
                page: n.data.page,
                pagesize: n.data.pagesize
            };
            -1 != n.data.curr && (i.cid = n.data.pclass[n.data.curr].id), a.util.request({
                url: "entry/wxapp/service",
                data: i,
                success: function(a) {
                    var t = a.data;
                    wx.stopPullDownRefresh(), "" != t.data ? (e += 1, n.setData({
                        list: n.data.list.concat(t.data)
                    })) : s = !0;
                }
            });
        }
    }
});