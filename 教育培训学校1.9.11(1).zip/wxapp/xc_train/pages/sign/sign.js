function a(a, t, e) {
    return t in a ? Object.defineProperty(a, t, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : a[t] = e, a;
}

function t(a) {
    var t = a.data.name, e = a.data.mobile, o = a.data.store_id;
    "" != o && null != o || (i = !1);
    var i = !0;
    "" != a.data.pid && null != a.data.pid || "" != a.data.cut && null != a.data.cut || "" != a.data.group_service && null != a.data.group_service || (i = !1);
    var n = a.data.sign_config;
    1 == n.name_status && ("" != t && null != t || (i = !1)), 1 == n.mobile_status && ("" != e && null != e || (i = !1), 
    /^[1][0-9]{10}$/.test(e) || (i = !1)), a.setData({
        submit: i
    });
}

function e(a, t) {
    a.appId;
    var e = a.timeStamp.toString(), o = a.package, i = a.nonceStr, n = a.paySign.toUpperCase();
    wx.requestPayment({
        timeStamp: e,
        nonceStr: i,
        package: o,
        signType: "MD5",
        paySign: n,
        success: function(a) {
            wx.showToast({
                title: "支付成功",
                icon: "success",
                duration: 2e3
            }), setTimeout(function() {
                "" != t.data.group_service && null != t.data.group_service ? wx.reLaunch({
                    url: "../group/order/index"
                }) : wx.reLaunch({
                    url: "../index/index"
                });
            }, 2e3);
        },
        fail: function(a) {}
    });
}

var o = getApp(), i = require("../common/common.js");

Page({
    data: {
        submit: !1,
        coupon_curr: -1,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        team_page: 1,
        team_pagesize: 20,
        team_isbottom: !1,
        is_load: !1,
        cut: ""
    },
    team_on: function() {
        this.setData({
            team_pages: !0
        });
    },
    team_close: function() {
        this.setData({
            team_pages: !1
        });
    },
    team_choose: function(a) {
        var e = this, i = a.currentTarget.dataset.index;
        e.setData({
            pid: e.data.team_list[i].id,
            team_pages: !1,
            coupon_curr: -1,
            coupon_price: ""
        }), o.util.request({
            url: "entry/wxapp/user",
            data: {
                op: "sign",
                pid: e.data.pid
            },
            success: function(a) {
                var t = a.data;
                "" != t.data && (e.setData({
                    list: t.data,
                    amount: "¥" + t.data.amount,
                    cut: ""
                }), "" != t.data.list && null != t.data.list ? e.setData({
                    coupon: t.data.list
                }) : e.setData({
                    coupon: []
                }));
            }
        }), t(e);
    },
    input: function(e) {
        var o = this, i = e.currentTarget.dataset.name;
        o.setData(a({}, i, e.detail.value)), t(o);
    },
    choose: function(a) {
        this.setData({
            shadow: !0,
            menu: !0
        });
    },
    menu_close: function() {
        this.setData({
            shadow: !1,
            menu: !1
        });
    },
    coupon_choose: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        if (e != t.data.coupon_curr) {
            var o = t.data.coupon[e].name, i = t.data.list.amount;
            i = (parseFloat(i) - parseFloat(o)).toFixed(2), t.setData({
                coupon_curr: e,
                coupon_price: "¥" + o,
                amount: "¥" + i
            });
        } else {
            var i = t.data.list.amount, n = t.data.card;
            "" != n && null != n && 1 == n.content.discount_status && (o_amount = (parseFloat(o_amount) * parseFloat(n.content.discount) / 10).toFixed(2)), 
            t.setData({
                coupon_curr: -1,
                coupon_price: "",
                amount: "¥" + t.data.list.amount
            });
        }
    },
    submit: function(a) {
        var t = this;
        if (t.data.submit) {
            var i = {
                name: t.data.name,
                mobile: t.data.mobile,
                form_id: a.detail.formId,
                order_type: 1,
                total: 1,
                store: t.data.store_id
            };
            "" != t.data.pid && null != t.data.pid && (i.pid = t.data.pid), "" != t.data.cut && null != t.data.cut && (i.cut = t.data.cut), 
            "" != t.data.group_service && null != t.data.group_service && (i.order_type = 7, 
            i.group_service = t.data.group_service, "" != t.data.group_param && null != t.data.group_param && (i.group_param = t.data.group_param), 
            "" != t.data.group_id && null != t.data.group_id && (i.group_id = t.data.group_id)), 
            "" != t.data.mobile2 && null != t.data.mobile2 && (i.mobile2 = t.data.mobile2), 
            -1 != t.data.coupon_curr && (i.coupon_id = t.data.coupon[t.data.coupon_curr].cid), 
            "" != t.data.content && null != t.data.content && (i.content = t.data.content), 
            "" != t.data.tui && null != t.data.tui && (i.tui = t.data.tui), "" != t.data.sign_config && null != t.data.sign_config && "" != t.data.sign_config.list && null != t.data.sign_config.list && (i.form = JSON.stringify(t.data.sign_config.list)), 
            o.util.request({
                url: "entry/wxapp/setorder",
                data: i,
                success: function(a) {
                    var o = a.data;
                    "" != o.data && (1 == o.data.status ? (wx.showToast({
                        title: "支付成功",
                        icon: "success",
                        duration: 2e3
                    }), setTimeout(function() {
                        "" != t.data.group_service && null != t.data.group_service ? wx.reLaunch({
                            url: "../group/order/index"
                        }) : wx.reLaunch({
                            url: "../index/index"
                        });
                    }, 2e3)) : "" != o.data.errno && null != o.data.errno ? wx.showModal({
                        title: "错误",
                        content: o.data.message,
                        showCancel: !1
                    }) : e(o.data, t));
                }
            });
        }
    },
    store_on: function() {
        this.setData({
            store_page: !0
        });
    },
    store_choose: function(a) {
        var e = this, o = a.currentTarget.dataset.index;
        e.setData({
            store_id: e.data.store_list[o].id,
            store_name: e.data.store_list[o].name,
            store_page: !1
        }), t(e);
    },
    store_close: function() {
        this.setData({
            store_page: !1
        });
    },
    team_scroll: function() {
        var a = this;
        a.data.team_isbottom || a.data.is_load || (a.setData({
            is_load: !0
        }), o.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "sign",
                page: a.data.team_page,
                pagesize: a.data.team_pagesize
            },
            success: function(t) {
                var e = t.data;
                "" != e.data ? a.setData({
                    team_list: a.data.team_list.concat(e.data),
                    team_page: a.data.team_page + 1
                }) : a.setData({
                    team_isbottom: !0
                }), a.setData({
                    is_load: !1
                });
            }
        }));
    },
    store_scroll: function() {
        var a = this;
        if (!a.data.isbottom && !a.data.is_load) {
            a.setData({
                is_load: !0
            });
            var t = {
                op: "school",
                page: a.data.page,
                pagesize: a.data.pagesize
            };
            null != a.data.latitude && "" != a.data.latitude && (t.latitude = a.data.latitude), 
            null != a.data.longitude && "" != a.data.longitude && (t.longitude = a.data.longitude), 
            o.util.request({
                url: "entry/wxapp/index",
                data: t,
                success: function(t) {
                    var e = t.data;
                    "" != e.data ? a.setData({
                        list: a.data.store_list.concat(e.data),
                        page: a.data.page + 1
                    }) : a.setData({
                        isbottom: !0
                    }), a.setData({
                        is_load: !1
                    });
                }
            });
        }
    },
    sign_input: function(a) {
        var t = this, e = t.data.sign_config, o = a.currentTarget.dataset.index;
        e.list[o].value = a.detail.value, t.setData({
            sign_config: e
        });
    },
    onLoad: function(a) {
        var t = this;
        i.config(t), i.theme(t);
        var e = {
            op: "sign"
        };
        "" != a.pid && null != a.pid && (e.pid = a.pid, t.setData({
            pid: a.pid
        })), "" != a.cut && null != a.cut && (e.cut = a.cut, t.setData({
            cut: a.cut
        })), "" != a.group_service && null != a.group_service && (e.group_service = a.group_service, 
        t.setData({
            group_service: a.group_service
        }), "" != a.group_param && null != a.group_param && (e.group_param = a.group_param, 
        t.setData({
            group_param: a.group_param
        })), "" != a.group_id && null != a.group_id && (e.group_id = a.group_id, t.setData({
            group_id: a.group_id
        }))), o.util.request({
            url: "entry/wxapp/user",
            data: e,
            success: function(e) {
                var o = e.data;
                "" != o.data && (t.setData({
                    list: o.data,
                    amount: "¥" + o.data.amount
                }), "" != a.cut && null != a.cut || "" != a.group_service && null != a.group_service || t.setData({
                    pid: o.data.id
                }), "" != o.data.list && null != o.data.list && t.setData({
                    coupon: o.data.list
                }));
            }
        }), wx.getLocation({
            type: "wgs84",
            success: function(a) {
                var e = a.latitude, o = a.longitude;
                a.speed, a.accuracy;
                t.setData({
                    latitude: e,
                    longitude: o
                });
            },
            complete: function() {
                var a = {
                    op: "school",
                    page: t.data.page,
                    pagesize: t.data.pagesize
                };
                null != t.data.latitude && "" != t.data.latitude && (a.latitude = t.data.latitude), 
                null != t.data.longitude && "" != t.data.longitude && (a.longitude = t.data.longitude), 
                o.util.request({
                    url: "entry/wxapp/index",
                    data: a,
                    success: function(a) {
                        var e = a.data;
                        "" != e.data ? t.setData({
                            store_list: e.data,
                            page: t.data.page + 1
                        }) : t.setData({
                            isbottom: !0
                        });
                    }
                });
            }
        }), o.util.request({
            url: "entry/wxapp/service",
            showLoading: !1,
            data: {
                op: "sign",
                page: t.data.team_page,
                pagesize: t.data.team_pagesize
            },
            success: function(a) {
                var e = a.data;
                "" != e.data ? t.setData({
                    team_list: e.data,
                    team_page: t.data.team_page + 1
                }) : t.setData({
                    team_isbottom: !0
                });
            }
        }), o.util.request({
            url: "entry/wxapp/user",
            showLoading: !1,
            data: {
                op: "sign_config"
            },
            success: function(a) {
                var e = a.data;
                "" != e.data ? t.setData({
                    sign_config: e.data
                }) : t.setData({
                    sign_config: {
                        name_status: 1,
                        mobile_status: 1,
                        coupon_status: 1,
                        content_status: 1,
                        tui_status: 1
                    }
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        i.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        wx.stopPullDownRefresh();
    },
    onReachBottom: function() {}
});