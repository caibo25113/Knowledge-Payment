var t = getApp(), a = require("../common/common.js"), n = 1, e = !1;

Page({
    data: {
        pagePath: "/xc_train/pages/active/list",
        list: []
    },
    to_detail: function(t) {
        var a = this, n = t.currentTarget.dataset.index, e = a.data.list;
        "" != e[n].link && null != e[n].link ? wx.navigateTo({
            url: "../about/link?&url=" + escape(e[n].link)
        }) : wx.navigateTo({
            url: "active?&id=" + e[n].id
        });
    },
    onLoad: function(t) {
        var n = this;
        a.config(n), a.theme(n), n.getData(!0);
    },
    onReady: function() {},
    onShow: function() {
        a.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var i = this;
        a && (n = 1, e = !1, i.setData({
            list: []
        })), e || t.util.request({
            url: "entry/wxapp/user",
            data: {
                op: "active",
                page: n,
                pagesize: 20
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var a = t.data;
                "" != a.data ? (n += 1, i.setData({
                    list: i.data.list.concat(a.data)
                })) : e = !0;
            }
        });
    }
});