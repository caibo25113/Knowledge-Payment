var t, a, e, n = getApp(), s = require("../../common/common.js"), o = require("../../../../wxParse/wxParse.js");

Page({
    data: {},
    rule_on: function() {
        this.setData({
            rule_status: !0
        });
    },
    rule_close: function() {
        this.setData({
            rule_status: !1
        });
    },
    onLoad: function(r) {
        var i = this;
        s.config(i), s.theme(i);
        var u = {
            op: "group_share",
            id: t = r.id
        };
        "" != r.order && null != r.order && (e = r.order, u.order = e), n.util.request({
            url: "entry/wxapp/service",
            data: u,
            success: function(t) {
                var e = t.data;
                if ("" != e.data) {
                    if (i.setData({
                        list: e.data
                    }), "" != e.data.service_data && null != e.data.service_data && "" != e.data.service_data.content && null != e.data.service_data.content) {
                        var n = e.data.service_data.content;
                        o.wxParse("content2", "html", n, i, 5);
                    }
                    -1 == i.data.list.status && (a = i.data.list.fail, i.timeDown());
                }
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        wx.stopPullDownRefresh();
    },
    onReachBottom: function() {},
    timeDown: function() {
        var t = this, e = setInterval(function() {
            var n = t.data.list;
            a > 0 ? (n.hour = parseInt(a / 3600), n.min = parseInt(a % 3600 / 60), n.second = parseInt(a % 60), 
            a -= 1, t.setData({
                list: n
            })) : (n.status = 2, t.setData({
                list: n
            }), clearInterval(e));
        }, 1e3);
    }
});