var t, a = getApp(), e = require("../../common/common.js"), n = 1, r = !1;

Page({
    data: {
        tab: [ "全部", "拼团中", "待核销", "已核销", "退款" ],
        tabCurr: 0
    },
    tabChange: function(t) {
        var a = this, e = t.currentTarget.id;
        e != a.data.tabCurr && (a.setData({
            tabCurr: e
        }), a.getData(!0));
    },
    code: function(t) {
        var a = this, n = t.currentTarget.dataset.index, r = a.data.list;
        e.createQrCode(r[n].out_trade_no, "mycanvas", .4), a.setData({
            canshow: !0,
            menu: !0
        });
    },
    canshow: function() {
        this.setData({
            canshow: !1,
            menu: !1
        });
    },
    onLoad: function(t) {
        var a = this;
        e.config(a), e.theme(a), a.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    onShareAppMessage: function(t) {
        var a = this, e = a.data.config.title, n = "/xc_train/pages/base/base";
        if ("button" === t.from) {
            var r = t.target.dataset.index, o = a.data.list;
            e = o[r].title;
            var s = "/xc_train/pages/group/share/index?&id=" + o[r].group_id + "&order=" + o[r].id;
            n = n + "?&share=" + (s = escape(s));
        }
        return {
            title: e,
            path: n,
            success: function(t) {
                console.log(t);
            },
            fail: function(t) {
                console.log(t);
            }
        };
    },
    getData: function(t) {
        var e = this;
        t && (n = 1, r = !1, e.setData({
            list: []
        })), r || a.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "group_order",
                page: n,
                pagesize: 20,
                curr: e.data.tabCurr
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var a = t.data;
                "" != a.data ? (e.setData({
                    list: e.data.list.concat(a.data)
                }), e.timeDown(), n += 1) : r = !0;
            }
        });
    },
    timeDown: function() {
        var a = this;
        clearInterval(t), t = setInterval(function() {
            for (var e = a.data.list, n = -1, r = 0; r < e.length; r++) if (1 == e[r].status && -1 == e[r].group_status) {
                var o = parseInt(e[r].fail);
                o > 0 ? (n = 1, e[r].hour = parseInt(o / 3600), e[r].min = parseInt(o % 3600 / 60), 
                e[r].second = parseInt(o % 60), e[r].fail = o - 1) : (e[r].status = 2, e[r].group_status = 2);
            }
            a.setData({
                list: e
            }), -1 == n && clearInterval(t);
        }, 1e3);
    }
});