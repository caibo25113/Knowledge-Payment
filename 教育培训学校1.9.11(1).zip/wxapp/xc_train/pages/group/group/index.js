var t, a, s = getApp(), e = require("../../common/common.js"), n = require("../../../../wxParse/wxParse.js");

Page({
    data: {
        nav: [ "详情", "评论" ],
        curr: 1,
        param: -1,
        page: 1,
        pagesize: 20,
        isbottim: !1
    },
    tab: function(t) {
        var a = this, s = t.currentTarget.dataset.index;
        s != a.data.curr && a.setData({
            curr: s
        });
    },
    zan: function() {
        var a = this;
        -1 == a.data.list.zan_user && s.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "group_zan",
                id: t
            },
            success: function(t) {
                if ("" != t.data.data) {
                    wx.showToast({
                        title: "点赞成功",
                        icon: "success",
                        duration: 2e3
                    });
                    var s = a.data.list;
                    s.zan_user = 1, s.zan = parseInt(s.zan) + 1, a.setData({
                        list: s
                    });
                }
            }
        });
    },
    input: function(t) {
        this.setData({
            content: t.detail.value
        });
    },
    discuss_on: function() {
        var a = this, e = a.data.content;
        "" != e && null != e ? s.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "discuss_on",
                id: t,
                content: e,
                type: 5
            },
            success: function(t) {
                if ("" != t.data.data) {
                    wx.showToast({
                        title: "评论成功",
                        icon: "success",
                        duration: 2e3
                    });
                    var s = a.data.list;
                    s.discuss = parseInt(s.discuss) + 1, a.setData({
                        content: "",
                        list: s
                    }), a.getDiscuss(!0);
                }
            }
        }) : wx.showModal({
            title: "错误",
            content: "评论内容不能为空",
            success: function(t) {
                t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
            }
        });
    },
    param_choose: function(t) {
        var a = this, s = t.currentTarget.dataset.index;
        s != a.data.param && a.setData({
            param: s
        });
    },
    submit: function() {
        var a = this;
        -1 != a.data.param ? wx.navigateTo({
            url: "../../sign/sign?&group_service=" + t + "&group_param=" + a.data.param
        }) : wx.showModal({
            title: "提示",
            content: "请选择人数",
            showCancel: !1
        });
    },
    onLoad: function(a) {
        var s = this;
        e.config(s), e.theme(s), t = a.id, s.getData(), s.getDiscuss(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {
        var t = this;
        2 == t.data.curr && t.getDiscuss(!1);
    },
    onShareAppMessage: function() {
        var a = this, e = "/xc_train/pages/group/group/index?&id=" + t;
        return e = escape(e), {
            title: a.data.config.title + "-" + a.data.list.service_name + " " + a.data.list.mark,
            path: "/xc_train/pages/base/base?&share=" + e + "&share_id=" + s.userinfo.id,
            success: function(t) {
                console.log(t);
            },
            fail: function(t) {
                console.log(t);
            }
        };
    },
    getData: function() {
        var a = this;
        s.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "group_detail",
                id: t
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var s = t.data;
                if ("" != s.data && (a.setData({
                    list: s.data
                }), a.timeDown(), "" != s.data.content && null != s.data.content)) {
                    var e = s.data.content;
                    n.wxParse("content2", "html", e, a, 5);
                }
            }
        });
    },
    timeDown: function() {
        var t = this;
        clearInterval(a);
        var s = t.data.list;
        "" != s.group_list && null != s.group_list && (a = setInterval(function() {
            for (var s = t.data.list.group_list, e = -1, n = 0; n < s.length; n++) {
                var i = parseInt(s[n].fail);
                i > 0 ? (e = 1, s[n].hour = parseInt(i / 3600), s[n].min = parseInt(i % 3600 / 60), 
                s[n].second = parseInt(i % 60), s[n].fail = i - 1) : s[n].status = 2;
            }
            var o = t.data.list;
            o.group_list = s, t.setData({
                list: o
            }), -1 == e && clearInterval(a);
        }, 1e3));
    },
    getDiscuss: function(a) {
        var e = this;
        a && e.setData({
            page: 1,
            isbottim: !1,
            tui: []
        }), e.data.isbottim || s.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "discuss",
                page: e.data.page,
                pagesize: e.data.pagesize,
                type: 5,
                id: t
            },
            success: function(t) {
                var a = t.data;
                wx.stopPullDownRefresh(), "" != a.data ? e.setData({
                    tui: e.data.tui.concat(a.data),
                    page: e.data.page + 1
                }) : e.setData({
                    isbottim: !0
                });
            }
        });
    }
});