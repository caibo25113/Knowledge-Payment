var t, a = getApp(), n = require("../common/common.js");

Page({
    data: {},
    call: function(t) {
        var a = this;
        wx.makePhoneCall({
            phoneNumber: a.data.list.mobile
        });
    },
    map: function(t) {
        var a = this;
        wx.openLocation({
            latitude: parseFloat(a.data.list.latitude),
            longitude: parseFloat(a.data.list.longitude),
            name: a.data.list.address,
            address: a.data.list.address,
            scale: 28
        });
    },
    qie: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    onLoad: function(a) {
        var o = this;
        n.config(o), n.theme(o), t = a.id, o.getData();
    },
    onReady: function() {},
    onShow: function() {
        n.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    getData: function() {
        var n = this;
        a.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "school_detail",
                id: t
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var a = t.data;
                "" != a.data && n.setData({
                    list: a.data
                });
            }
        });
    }
});