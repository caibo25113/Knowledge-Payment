var t = getApp(), a = require("../common/common.js"), n = 1, o = !1, e = "", i = "";

Page({
    data: {
        list: []
    },
    onLoad: function(t) {
        var n = this;
        a.config(n), a.theme(n), wx.getLocation({
            type: "wgs84",
            success: function(t) {
                e = t.latitude, i = t.longitude;
            },
            complete: function() {
                n.getData(!0);
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        a.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var s = this;
        if (a && (n = 1, o = !1, s.setData({
            list: []
        })), !o) {
            var c = {
                op: "school",
                page: n,
                pagesize: 20,
                latitude: e,
                longitude: i
            };
            t.util.request({
                url: "entry/wxapp/index",
                data: c,
                success: function(t) {
                    var a = t.data;
                    wx.stopPullDownRefresh(), "" != a.data ? (n += 1, s.setData({
                        list: s.data.list.concat(a.data)
                    })) : o = !0;
                }
            });
        }
    }
});