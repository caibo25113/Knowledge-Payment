function t(t, e) {
    var a = new RegExp("(^|&)" + e + "=([^&]*)(&|$)"), n = t.split("?")[1].match(a);
    return null != n ? unescape(n[2]) : null;
}

var e = getApp(), a = require("../../common/common.js"), n = require("../../../../wxParse/wxParse.js");

Page({
    data: {
        type: 1,
        withdraw_start: .01,
        isLoading: !1
    },
    tab: function(t) {
        var e = this, a = t.currentTarget.dataset.index;
        a != e.data.type && e.setData({
            type: a
        });
    },
    upload: function() {
        var a = this, n = "entry/wxapp/shareUpload";
        -1 == n.indexOf("http://") && -1 == n.indexOf("https://") && (n = e.util.url(n));
        var s = wx.getStorageSync("userInfo").sessionid;
        !t(n, "state") && s && (n = n + "&state=we7sid-" + s), n = n + "&state=we7sid-" + s;
        var r = getCurrentPages();
        r.length && (r = r[getCurrentPages().length - 1]) && r.__route__ && (n = n + "&m=" + r.__route__.split("/")[0]), 
        wx.chooseImage({
            count: 1,
            success: function(t) {
                var e = t.tempFilePaths;
                wx.uploadFile({
                    url: n,
                    filePath: e[0],
                    name: "file",
                    formData: {
                        user: "test"
                    },
                    success: function(t) {
                        var e = JSON.parse(t.data);
                        a.setData({
                            code: e.data.code,
                            share_code: e.data.share_code
                        });
                    }
                });
            }
        });
    },
    step_on: function() {
        var t = this;
        1 == t.data.type ? t.setData({
            step2: !0
        }) : 2 == t.data.type && t.setData({
            step1: !0
        });
    },
    step_close: function() {
        this.setData({
            step1: !1,
            step2: !1
        });
    },
    submit: function(t) {
        var n = this, s = t.detail.value, r = [];
        r = [ {
            name: "xc[type]",
            required: !0,
            required_msg: "请选择账户类型"
        }, {
            name: "xc[username]",
            required: !0,
            required_msg: "请输入账号"
        }, {
            name: "xc[name]",
            required: !0,
            required_msg: "请输入姓名"
        }, {
            name: "xc[mobile]",
            required: !0,
            required_msg: "请输入手机号码",
            tel: !0,
            tel_msg: "请输入正确的手机号码"
        }, {
            name: "xc[amount]",
            required: !0,
            required_msg: "请输入提现金额",
            gt: n.data.withdraw_start,
            gt_msg: "提现金额不能少于" + n.data.withdraw_start,
            lt: n.data.share.user.share_fee,
            lt_msg: "余额不足"
        }, {
            name: "xc[code]",
            required: !0,
            required_msg: "请上传收款码"
        } ];
        var i = a.formCheck(s, r, n);
        i && !n.data.isLoading && (n.setData({
            isLoading: !0
        }), s.op = "share_withdraw", e.util.request({
            url: "entry/wxapp/index",
            method: "POST",
            data: s,
            success: function(t) {
                "" != t.data.data && (wx.showToast({
                    title: "提交成功"
                }), setTimeout(function() {
                    wx.navigateBack({
                        delta: 1
                    });
                }, 2e3));
            },
            complete: function() {
                n.setData({
                    isLoading: !1
                });
            }
        }));
    },
    onLoad: function(t) {
        var e = this;
        a.config(e), a.theme(e), e.getData();
    },
    onReady: function() {},
    onShow: function() {
        a.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    getData: function() {
        var t = this;
        e.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "share_config"
            },
            success: function(e) {
                wx.stopPullDownRefresh();
                var a = e.data;
                "" != a.data && (t.setData({
                    share: a.data
                }), "" != a.data.withdraw_content && null != a.data.withdraw_content && n.wxParse("article", "html", a.data.withdraw_content, t, 5), 
                "" != a.data.withdraw_limit && null != a.data.withdraw_limit && t.setData({
                    withdraw_start: a.data.withdraw_limit
                }));
            }
        });
    }
});