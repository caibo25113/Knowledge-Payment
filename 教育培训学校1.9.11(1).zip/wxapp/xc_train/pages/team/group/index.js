function a(a) {
    e = setInterval(function() {
        var t = a.data.fail;
        if (t > 0) {
            t -= 1;
            var r = a.data.times;
            r[0] = parseInt(t / 86400), r[1] = parseInt(t % 86400 / 3600), r[2] = parseInt(t % 3600 / 60), 
            r[3] = t % 60, a.setData({
                fail: t,
                times: r
            });
        } else {
            clearInterval(e);
            var n = a.data.group;
            -1 == n.curr && (n.curr = 2), a.setData({
                times: [ 0, 0, 0, 0 ],
                fail: 0,
                group: n
            });
        }
    }, 1e3);
}

var t, e, r = getApp(), n = require("../../common/common.js"), i = require("../../../../wxParse/wxParse.js");

Page({
    data: {
        fail: 0,
        times: [ 0, 0, 0, 0 ],
        service_rule: !1,
        numbervalue: 1,
        format: -1
    },
    service_on: function() {
        this.setData({
            service_rule: !0
        });
    },
    service_close: function() {
        this.setData({
            service_rule: !1
        });
    },
    menu_on: function() {
        this.setData({
            shadow2: !0,
            teamBuy: !0
        });
    },
    menu_close: function(a) {
        this.setData({
            shadow2: !1,
            teamBuy: !1
        });
    },
    numPlus: function() {
        var a = this, t = a.data.numbervalue;
        t++, a.setData({
            numbervalue: t
        });
    },
    numMinus: function() {
        var a = this, t = a.data.numbervalue;
        t > 1 && (t--, a.setData({
            numbervalue: t
        }));
    },
    valChange: function(a) {
        var t = this, e = a.detail.value;
        e >= 1 || (e = 1), t.setData({
            numbervalue: e
        });
    },
    radiochange: function(a) {
        var t = this, e = a.detail.value;
        e != t.data.format && t.setData({
            format: e
        });
    },
    submit: function() {
        var a = this;
        wx.navigateTo({
            url: "../pay/index?&id=" + a.data.service.id + "&format=" + a.data.format + "&member=" + a.data.numbervalue + "&group_id=" + a.data.group.id
        });
    },
    onLoad: function(a) {
        var e = this;
        n.config(e), n.theme(e), t = a.id, e.getData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var a = this, t = "/xc_train/pages/team/group/index";
        return t = escape(t), {
            title: a.data.config.title + "-" + a.data.service.name,
            path: "/xc_train/pages/base/base?&share=" + t + "&share_id=" + r.userinfo.id,
            success: function(a) {
                console.log(a);
            },
            fail: function(a) {
                console.log(a);
            }
        };
    },
    getData: function() {
        var n = this;
        r.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "mall_team_group",
                id: t
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var r = t.data;
                if ("" != r.data) {
                    if (clearInterval(e), n.setData({
                        order: r.data.order,
                        group: r.data.group,
                        service: r.data.service
                    }), "" != r.data.service.format && null != r.data.service.format && n.setData({
                        format: 0
                    }), "" != r.data.service.content && null != r.data.service.content) i.wxParse("article", "html", r.data.service.content, n, 0);
                    "" != r.data.team && null != r.data.team && n.setData({
                        team: r.data.team
                    }), "" != r.data.group_order && null != r.data.group_order && n.setData({
                        group_order: r.data.group_order
                    }), r.data.service.fail > 0 && (a(n), n.setData({
                        fail: r.data.service.fail
                    }));
                }
            }
        });
    }
});