function t(t, a) {
    var e = new RegExp("(^|&)" + a + "=([^&]*)(&|$)"), n = t.split("?")[1].match(e);
    return null != n ? unescape(n[2]) : null;
}

var a = getApp(), e = require("../../common/common.js"), n = require("../../../../wxParse/wxParse.js");

Page({
    data: {
        xc_admin: "team",
        nav: [ "支付宝提现", "微信提现" ],
        curr: 0,
        withdraw_start: .01,
        isLoading: !1,
        type: 2,
        amount: ""
    },
    tab: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        if (e != a.data.curr) {
            var n = 1;
            0 == e ? n = 2 : 1 == e && (n = 1), a.setData({
                curr: e,
                type: n
            });
        }
    },
    step_on: function() {
        var t = this;
        1 == t.data.curr ? t.setData({
            step2: !0
        }) : 0 == t.data.curr && t.setData({
            step1: !0
        });
    },
    step_close: function() {
        this.setData({
            step1: !1,
            step2: !1
        });
    },
    upload: function() {
        var e = this, n = "entry/wxapp/shareUpload";
        -1 == n.indexOf("http://") && -1 == n.indexOf("https://") && (n = a.util.url(n));
        var i = wx.getStorageSync("userInfo").sessionid;
        !t(n, "state") && i && (n = n + "&state=we7sid-" + i), n = n + "&state=we7sid-" + i;
        var r = getCurrentPages();
        r.length && (r = r[getCurrentPages().length - 1]) && r.__route__ && (n = n + "&m=" + r.__route__.split("/")[0]), 
        wx.chooseImage({
            count: 1,
            success: function(t) {
                var a = t.tempFilePaths;
                wx.uploadFile({
                    url: n,
                    filePath: a[0],
                    name: "file",
                    formData: {
                        user: "test"
                    },
                    success: function(t) {
                        var a = JSON.parse(t.data);
                        e.setData({
                            code: a.data.code,
                            share_code: a.data.share_code
                        });
                    }
                });
            }
        });
    },
    widthdraw_all: function(t) {
        var a = this;
        a.setData({
            amount: a.data.list.user.team_fee
        });
    },
    submit: function(t) {
        var n = this, i = t.detail.value, r = [];
        r = [ {
            name: "xc[type]",
            required: !0,
            required_msg: "请选择账户类型"
        }, {
            name: "xc[username]",
            required: !0,
            required_msg: "请输入账号"
        }, {
            name: "xc[name]",
            required: !0,
            required_msg: "请输入姓名"
        }, {
            name: "xc[mobile]",
            required: !0,
            required_msg: "请输入手机号码",
            tel: !0,
            tel_msg: "请输入正确的手机号码"
        }, {
            name: "xc[amount]",
            required: !0,
            required_msg: "请输入提现金额",
            gt: n.data.withdraw_start,
            gt_msg: "提现金额不能少于" + n.data.withdraw_start,
            lt: n.data.list.user.team_fee,
            lt_msg: "余额不足"
        }, {
            name: "xc[code]",
            required: !0,
            required_msg: "请上传收款码"
        } ];
        var s = e.formCheck(i, r, n);
        s && !n.data.isLoading && (n.setData({
            isLoading: !0
        }), i.op = "team_withdraw_fee", a.util.request({
            url: "entry/wxapp/index",
            method: "POST",
            data: i,
            success: function(t) {
                "" != t.data.data && (wx.showToast({
                    title: "提交成功"
                }), setTimeout(function() {
                    wx.navigateBack({
                        delta: 1
                    });
                }, 2e3));
            },
            complete: function() {
                n.setData({
                    isLoading: !1
                });
            }
        }));
    },
    onLoad: function(t) {
        var a = this;
        e.config(a), e.theme(a), a.getData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    getData: function() {
        var t = this;
        a.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "team_withdraw"
            },
            success: function(a) {
                wx.stopPullDownRefresh();
                var e = a.data;
                "" != e.data && (t.setData({
                    list: e.data
                }), "" != e.data.config.withdraw_content && null != e.data.config.withdraw_content && n.wxParse("article", "html", e.data.config.withdraw_content, t, 5), 
                "" != e.data.config.withdraw_limit && null != e.data.config.withdraw_limit && t.setData({
                    withdraw_start: e.data.config.withdraw_limit
                }));
            }
        });
    }
});