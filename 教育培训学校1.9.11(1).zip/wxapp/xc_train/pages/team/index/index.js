var t = getApp(), a = require("../../common/common.js"), n = 1, o = !1;

Page({
    data: {
        list: []
    },
    onLoad: function(t) {
        var n = this;
        a.config(n), a.theme(n), n.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var e = this;
        a && (n = 1, o = !1, e.setData({
            list: []
        })), o || t.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "mall_team",
                page: n,
                pagesize: 20
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var a = t.data;
                "" != a.data ? (n += 1, e.setData({
                    list: e.data.list.concat(a.data)
                })) : o = !0;
            }
        });
    }
});