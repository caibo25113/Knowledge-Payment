function a(a) {
    e = setInterval(function() {
        var t = a.data.fail;
        if (t > 0) {
            t -= 1;
            var r = a.data.times;
            r[0] = parseInt(t / 86400), r[1] = parseInt(t % 86400 / 3600), r[2] = parseInt(t % 3600 / 60), 
            r[3] = parseInt(t % 60), a.setData({
                times: r,
                fail: t
            });
        } else {
            clearInterval(e);
            var n = a.data.list;
            n.status = -1, a.setData({
                times: [ 0, 0, 0, 0 ],
                fail: 0,
                list: n
            });
        }
    }, 1e3);
}

var t, e, r = getApp(), n = require("../../common/common.js"), o = require("../../../../wxParse/wxParse.js"), i = 1, d = !1, s = 1, u = !1;

Page({
    data: {
        nav: [ "团购详情", "正在接龙" ],
        curr: 0,
        fail: 0,
        times: [ 0, 0, 0, 0 ],
        numbervalue: 1,
        code: "",
        format: -1,
        order: [],
        order_index: -1,
        order_list: [],
        group_id: ""
    },
    share: function() {
        this.setData({
            showShare: !0
        });
    },
    closeShare: function() {
        this.setData({
            showShare: !1
        });
    },
    showhb: function() {
        var a = this;
        "" != a.data.code && null != a.data.code ? a.setData({
            showhb: !0,
            showShare: !1
        }) : r.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "mall_team_code",
                id: t
            },
            success: function(t) {
                var e = t.data;
                "" != e.data && (a.setData({
                    code: e.data.code
                }), a.setData({
                    showhb: !0,
                    showShare: !1
                }));
            }
        });
    },
    closehb: function() {
        this.setData({
            showhb: !1
        });
    },
    dlimg: function() {
        var a = this;
        n.downloadFile(a.data.code);
    },
    tab: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.curr && t.setData({
            curr: e
        });
    },
    menu_on: function(a) {
        var t = this, e = a.currentTarget.dataset.group;
        if (3 == e) {
            var r = a.currentTarget.dataset.index;
            t.setData({
                group_id: t.data.order[r].id
            });
        }
        t.setData({
            shadow2: !0,
            teamBuy: !0,
            group: e
        });
    },
    menu_close: function(a) {
        this.setData({
            shadow2: !1,
            teamBuy: !1
        });
    },
    numPlus: function() {
        var a = this, t = a.data.numbervalue;
        t++, a.setData({
            numbervalue: t
        });
    },
    numMinus: function() {
        var a = this, t = a.data.numbervalue;
        t > 1 && (t--, a.setData({
            numbervalue: t
        }));
    },
    valChange: function(a) {
        var t = this, e = a.detail.value;
        e >= 1 || (e = 1), t.setData({
            numbervalue: e
        });
    },
    radiochange: function(a) {
        var t = this, e = a.detail.value;
        e != t.data.format && t.setData({
            format: e
        });
    },
    order_on: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        t.setData({
            order_index: e
        }), t.getOrderGroup(!0);
    },
    order_close: function() {
        this.setData({
            order_index: -1
        });
    },
    submit: function() {
        var a = this;
        1 == a.data.group ? wx.navigateTo({
            url: "../pay/index?&id=" + t + "&format=" + a.data.format + "&member=" + a.data.numbervalue
        }) : -1 == a.data.group ? wx.navigateTo({
            url: "../../mall/porder?&id=" + a.data.list.service + "&format=" + a.data.format + "&member=" + a.data.numbervalue
        }) : 3 == a.data.group && wx.navigateTo({
            url: "../pay/index?&id=" + t + "&format=" + a.data.format + "&member=" + a.data.numbervalue + "&group_id=" + a.data.group_id
        });
    },
    onLoad: function(a) {
        var e = this;
        n.config(e), n.theme(e), t = a.id, e.getData(), e.getOrder(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {
        var a = this;
        1 == a.data.curr && (-1 == a.data.order_index ? a.getOrder(!1) : a.getOrderGroup(!1));
    },
    onShareAppMessage: function() {
        var a = this, t = "/xc_train/pages/team/index/detail";
        return t = escape(t), {
            title: a.data.config.title + "-" + a.data.list.name,
            path: "/xc_train/pages/base/base?&share=" + t + "&share_id=" + r.userinfo.id,
            success: function(a) {
                console.log(a);
            },
            fail: function(a) {
                console.log(a);
            }
        };
    },
    getData: function() {
        var n = this;
        r.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "mall_team_detail",
                id: t
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var r = t.data;
                if ("" != r.data) {
                    if (n.setData({
                        list: r.data,
                        fail: r.data.fail
                    }), "" != r.data.content && null != r.data.content) o.wxParse("article", "html", r.data.content, n, 0);
                    "" != r.data.format && null != r.data.format && n.setData({
                        format: 0
                    }), clearInterval(e), a(n);
                }
            }
        });
    },
    getOrder: function(a) {
        var e = this;
        a && (i = 1, d = !1, e.setData({
            order: []
        })), d || r.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "mall_team_detail_group",
                id: t,
                page: i,
                pagesize: 20
            },
            success: function(a) {
                var t = a.data;
                "" != t.data ? (e.setData({
                    order: e.data.order.concat(t.data)
                }), i += 1) : d = !0;
            }
        });
    },
    getOrderGroup: function(a) {
        var t = this;
        a && (s = 1, u = !1, t.setData({
            order_list: []
        })), u || r.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "mall_team_detail_group2",
                group: t.data.order[t.data.order_index].id,
                page: s,
                pagesize: 20
            },
            success: function(a) {
                var e = a.data;
                "" != e.data ? (t.setData({
                    order_list: t.data.order_list.concat(e.data)
                }), s += 1) : u = !0;
            }
        });
    }
});