function t(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

function a(t, a) {
    i = new o({
        canvasId: "areaCanvas",
        type: "area",
        categories: t,
        animation: !0,
        series: [ {
            name: "佣金",
            data: a,
            format: function(t) {
                return parseFloat(t).toFixed(2);
            }
        } ],
        yAxis: {
            format: function(t) {
                return t.toFixed(2);
            },
            min: 0,
            fontColor: "#c1c1c1",
            gridColor: "#efefef"
        },
        xAxis: {
            fontColor: "#c1c1c1",
            gridColor: "#efefef"
        },
        extra: {
            legendTextColor: "#f45a46"
        },
        width: r,
        height: 200
    });
}

var e = getApp(), n = require("../../common/common.js"), o = require("../../../../utils/wxcharts.js"), r = 320, i = null;

Page({
    data: {
        xc_admin: "team",
        footerCurr: 3,
        nav: [ "今日", "本周", "本月", "自定义" ],
        curr: 0
    },
    tab: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        e != a.data.curr && (a.setData({
            curr: e
        }), 3 != e && a.getData());
    },
    bindDateChange: function(a) {
        var e = this, n = a.currentTarget.dataset.name;
        e.setData(t({}, n, a.detail.value));
    },
    search: function() {
        this.getData();
    },
    onLoad: function(t) {
        var a = this;
        n.config(a), n.theme(a), a.getCount(), a.getData();
        try {
            var e = wx.getSystemInfoSync();
            r = e.windowWidth;
        } catch (t) {
            console.error("getSystemInfoSync failed!");
        }
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    getCount: function() {
        var t = this;
        e.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "team_count_table"
            },
            success: function(e) {
                wx.stopPullDownRefresh();
                var n = e.data;
                "" != n.data && (t.setData({
                    plan_start: n.data.plan_date,
                    plan_end: n.data.plan_date
                }), a(n.data.table_x, n.data.table_y));
            }
        });
    },
    getData: function() {
        var t = this;
        e.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "team_count",
                curr: t.data.curr
            },
            success: function(a) {
                wx.stopPullDownRefresh();
                var e = a.data;
                "" != e.data && t.setData({
                    list: e.data
                });
            }
        });
    }
});