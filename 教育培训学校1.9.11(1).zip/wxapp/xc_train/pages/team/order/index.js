var t = getApp(), a = require("../../common/common.js"), e = 1, n = !1;

Page({
    data: {
        tab: [ "全部", "接龙中", "待发货", "已发货" ],
        tabCurr: 0,
        list: []
    },
    tabChange: function(t) {
        var a = this, e = t.currentTarget.id;
        e != a.data.tabCurr && (a.setData({
            tabCurr: e
        }), a.getData(!0));
    },
    shFunc: function(t) {
        var e = this, n = t.currentTarget.dataset.index, i = e.data.list;
        a.createQrCode(i[n].out_trade_no, "mycanvas", .4), e.setData({
            canshow: !0,
            menu: !0
        });
    },
    canshow: function() {
        this.setData({
            canshow: !1,
            menu: !1
        });
    },
    onLoad: function(t) {
        var e = this;
        a.config(e), a.theme(e), e.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    onShareAppMessage: function(a) {
        var e = this, n = "/xc_train/pages/index/detail";
        n = escape(n);
        var i = e.data.config.title;
        if ("button" == a.from) {
            var o = a.target.dataset.index, s = e.data.list;
            n = "/xc_train/pages/team/group/index/detail?&id=" + s[o].id, i = i + " " + s[o].service_name;
        }
        return {
            title: i,
            path: "/xc_train/pages/base/base?&share=" + n + "&share_id=" + t.userinfo.id,
            success: function(t) {
                console.log(t);
            },
            fail: function(t) {
                console.log(t);
            }
        };
    },
    getData: function(a) {
        var i = this;
        a && (e = 1, n = !1, i.setData({
            list: []
        })), n || t.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "mall_team_order",
                page: e,
                pagesize: 20,
                curr: i.data.tabCurr
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var a = t.data;
                "" != a.data ? (e += 1, i.setData({
                    list: i.data.list.concat(a.data)
                })) : n = !0;
            }
        });
    }
});