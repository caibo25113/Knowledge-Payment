var t, n = getApp(), a = require("../../common/common.js");

Page({
    data: {},
    onLoad: function(n) {
        var o = this;
        a.config(o), a.theme(o), t = n.id, o.getData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    getData: function() {
        var a = this;
        n.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "mall_team_order_detail",
                id: t
            },
            success: function(t) {
                wx.stopPullDownRefresh();
                var n = t.data;
                "" != n.data && a.setData({
                    list: n.data
                });
            }
        });
    }
});