function t(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

var a, e = getApp(), n = require("../../common/common.js"), i = 1, r = !1;

Page((a = {
    data: {
        xc_admin: "team",
        footerCurr: 2,
        tab: [ "全部", "接龙中", "待发货", "已发货" ],
        tabCurr: 0,
        inputShowed: !1,
        inputVal: "",
        list: [],
        curr: 0
    },
    tabChange: function(t) {
        var a = this, e = t.currentTarget.id;
        e != a.data.tabCurr && (a.setData({
            tabCurr: e
        }), a.getData(!0));
    },
    showInput: function() {
        this.setData({
            inputShowed: !0
        });
    },
    hideInput: function() {
        this.setData({
            inputVal: "",
            inputShowed: !1
        });
    },
    clearInput: function() {
        this.setData({
            inputVal: ""
        });
    },
    inputTyping: function(t) {
        this.setData({
            inputVal: t.detail.value
        });
    },
    search: function() {
        this.getData(!0);
    },
    tab: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        e != a.data.curr && (a.setData({
            curr: e
        }), 3 != e && a.getData(!0));
    },
    bindDateChange: function(a) {
        var e = this, n = a.currentTarget.dataset.name;
        e.setData(t({}, n, a.detail.value));
    }
}, t(a, "search", function() {
    this.getData(!0);
}), t(a, "onLoad", function(t) {
    var a = this;
    n.config(a), n.theme(a);
    var e = new Date();
    e.setTime(e.getTime());
    var i = e.getFullYear(), r = e.getMonth() + 1;
    r < 10 && (r = "0" + r);
    var u = e.getDate();
    u < 10 && (u = "0" + u), a.setData({
        plan_start: i + "-" + r + "-" + u,
        plan_end: i + "-" + r + "-" + u
    }), a.getData(!0);
}), t(a, "onReady", function() {}), t(a, "onShow", function() {}), t(a, "onHide", function() {}), 
t(a, "onUnload", function() {}), t(a, "onPullDownRefresh", function() {
    this.getData(!0);
}), t(a, "onReachBottom", function() {
    this.getData(!1);
}), t(a, "getData", function(t) {
    var a = this;
    if (t && (i = 1, r = !1, a.setData({
        list: []
    })), !r) {
        var n = {
            op: "team_group_order",
            page: i,
            pagesize: 20,
            curr: a.data.tabCurr,
            curr2: a.data.curr,
            start_time: a.data.plan_start,
            end_time: a.data.plan_end
        };
        null != a.data.inputVal && (n.content = a.data.inputVal), e.util.request({
            url: "entry/wxapp/index",
            data: n,
            success: function(t) {
                wx.stopPullDownRefresh();
                var e = t.data;
                "" != e.data ? (i += 1, a.setData({
                    list: a.data.list.concat(e.data)
                })) : r = !0;
            }
        });
    }
}), a));