function t(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

function a(t, a) {
    t.appId;
    var e = t.timeStamp.toString(), o = t.package, n = t.nonceStr, d = t.paySign.toUpperCase();
    t.out_trade_no;
    wx.requestPayment({
        timeStamp: e,
        nonceStr: n,
        package: o,
        signType: "MD5",
        paySign: d,
        success: function(a) {
            wx.showToast({
                title: "支付成功",
                icon: "success",
                duration: 2e3
            }), setTimeout(function() {
                wx.reLaunch({
                    url: "../group/index?&id=" + t.order_id
                });
            }, 2e3);
        }
    });
}

var e = getApp(), o = require("../../common/common.js");

Page({
    data: {
        amount: 0,
        o_amount: 0,
        ticketCurr: 0,
        showTicket: !1,
        pei_type: 1
    },
    store_on: function() {
        this.setData({
            store_page: !0
        });
    },
    store_close: function() {
        this.setData({
            store_page: !1
        });
    },
    store_choose: function(t) {
        var a = this, e = t.currentTarget.dataset.index, o = a.data.store;
        a.setData({
            store_page: !1,
            store_id: o[e].id,
            store_name: o[e].name
        });
    },
    pei_change: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        e != a.data.pei_type && (a.setData({
            pei_type: e
        }), a.get_sum());
    },
    input: function(t) {
        this.setData({
            content: t.detail.value
        });
    },
    submit: function(t) {
        var o = this;
        if ("" == o.data.address || null == o.data.address) return wx.showModal({
            title: "提示",
            content: "请完善用户信息",
            showCancel: !1
        }), !1;
        if ("" == o.data.store_id || null == o.data.store_id) return wx.showModal({
            title: "提示",
            content: "请选择提货校区",
            showCancel: !1
        }), !1;
        var n = {
            id: o.data.id,
            store: o.data.store_id,
            format: o.data.format,
            member: o.data.member,
            pei_type: o.data.pei_type,
            form_id: t.detail.formId
        };
        "" != o.data.content && null != o.data.content && (n.content = o.data.content), 
        "" != o.data.group_id && null != o.data.group_id && (n.group_id = o.data.group_id), 
        e.util.request({
            url: "entry/wxapp/teamorder",
            data: n,
            success: function(t) {
                var e = t.data;
                "" != e.data && (1 == e.data.status ? "" != e.data.errno && null != e.data.errno ? wx.showModal({
                    title: "错误",
                    content: e.data.message,
                    showCancel: !1
                }) : a(e.data) : 2 == e.data.status && (wx.showToast({
                    title: "支付成功",
                    icon: "success",
                    duration: 2e3
                }), setTimeout(function() {
                    wx.reLaunch({
                        url: "../group/index?&id=" + e.data.order_id
                    });
                }, 2e3)));
            }
        });
    },
    onLoad: function(a) {
        var n = this;
        o.config(n), o.theme(n), n.setData({
            id: a.id,
            format: a.format,
            member: a.member
        });
        var d = {
            op: "mall_team_pay",
            id: a.id,
            format: a.format,
            member: a.member
        };
        "" != a.group_id && null != a.group_id && (d.group_id = a.group_id, n.setData({
            group_id: a.group_id
        })), wx.getLocation({
            type: "wgs84",
            success: function(t) {
                var a = t.latitude, e = t.longitude;
                n.setData({
                    latitude: a,
                    longitude: e
                });
            },
            complete: function() {
                null != n.data.latitude && "" != n.data.latitude && (d.latitude = n.data.latitude), 
                null != n.data.longitude && "" != n.data.longitude && (d.longitude = n.data.longitude), 
                e.util.request({
                    url: "entry/wxapp/index",
                    data: d,
                    success: function(a) {
                        var e = a.data;
                        "" != e.data && (n.setData(t({
                            team: e.data.team,
                            service: e.data.service,
                            amount: e.data.amount,
                            fee: e.data.fee,
                            store: e.data.store
                        }, "fee", e.data.fee)), "" != e.data.group && null != e.data.group && n.setData({
                            group: e.data.group
                        }), "" != e.data.group_sale && null != e.data.group_sale && n.setData({
                            group_sale: e.data.group_sale
                        }), n.get_sum());
                    }
                });
            }
        }), "" != n.data.config && null != n.data.config && 2 == n.data.config.mall_pei_type && n.setData({
            pei_type: 2
        });
    },
    onReady: function() {},
    onShow: function() {
        var t = this;
        o.audio_end(this), e.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "address"
            },
            success: function(a) {
                var e = a.data;
                "" != e.data && t.setData({
                    address: e.data
                });
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        wx.stopPullDownRefresh();
    },
    onReachBottom: function() {},
    get_sum: function() {
        var t = this, a = t.data.amount;
        "" != t.data.group_sale && null != t.data.group_sale && (a = (parseFloat(a) * parseFloat(t.data.group_sale) / 10).toFixed(2)), 
        1 == t.data.pei_type && "" != t.data.fee && null != t.data.fee && (a = (parseFloat(a) + parseFloat(t.data.fee)).toFixed(2)), 
        t.setData({
            o_amount: a
        });
    }
});