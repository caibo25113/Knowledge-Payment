var n = getApp(), e = require("../../common/common.js");

Page({
    data: {
        xc_admin: "team",
        footerCurr: 4,
        nav: [ {
            img: "/xc_train/resource/team_menu01.png",
            name: "提现申请",
            link: "../withdraw/index"
        }, {
            img: "/xc_train/resource/team_menu02.png",
            name: "团员订单",
            link: "../order/group"
        }, {
            img: "/xc_train/resource/team_menu03.png",
            name: "佣金明细",
            link: "../record/index"
        }, {
            img: "/xc_train/resource/team_menu04.png",
            name: "销售统计",
            link: "../count/index"
        } ]
    },
    onLoad: function(n) {
        var t = this;
        e.config(t), e.theme(t), t.getData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    getData: function() {
        var e = this;
        n.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "team_index"
            },
            success: function(n) {
                wx.stopPullDownRefresh();
                var t = n.data;
                "" != t.data && e.setData({
                    list: t.data
                });
            }
        });
    }
});