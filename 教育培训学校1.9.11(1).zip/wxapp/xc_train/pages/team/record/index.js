function t(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

var a = getApp(), e = require("../../common/common.js"), r = 1, n = !1;

Page({
    data: {
        xc_admin: "team",
        order: [],
        curr: 0
    },
    tab: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        e != a.data.curr && (a.setData({
            curr: e
        }), 3 == a.data.curr || a.getOrder(!0));
    },
    bindDateChange: function(a) {
        var e = this, r = a.currentTarget.dataset.name;
        e.setData(t({}, r, a.detail.value));
    },
    search: function() {
        this.getOrder(!0);
    },
    onLoad: function(t) {
        var a = this;
        e.config(a), e.theme(a), a.getData(), a.getOrder(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(), this.getOrder(!0);
    },
    onReachBottom: function() {
        this.getOrder(!1);
    },
    getData: function() {
        var t = this;
        a.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "team_record"
            },
            success: function(a) {
                wx.stopPullDownRefresh();
                var e = a.data;
                "" != e.data && t.setData({
                    list: e.data,
                    plan_start: e.data.plan_date,
                    plan_end: e.data.plan_date
                });
            }
        });
    },
    getOrder: function(t) {
        var e = this;
        t && (r = 1, n = !1, e.setData({
            order: []
        })), n || a.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "team_order",
                page: r,
                pagesize: 20,
                curr: e.data.curr,
                start_time: e.data.plan_start,
                end_time: e.data.plan_end
            },
            success: function(t) {
                var a = t.data;
                "" != a.data ? (r += 1, e.setData({
                    order: e.data.order.concat(a.data)
                })) : n = !0;
            }
        });
    }
});