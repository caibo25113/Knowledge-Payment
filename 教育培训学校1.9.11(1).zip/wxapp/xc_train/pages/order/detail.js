var t, n = getApp(), o = require("../common/common.js");

Page({
    data: {},
    onLoad: function(n) {
        var a = this;
        o.config(a), o.theme(a), t = n.id, a.getData();
    },
    onReady: function() {},
    onShow: function() {
        o.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData();
    },
    onReachBottom: function() {},
    getData: function() {
        var o = this;
        n.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "mall_order_detail",
                id: t
            },
            success: function(t) {
                var n = t.data;
                wx.stopPullDownRefresh(), "" != n.data && o.setData({
                    list: n.data
                });
            }
        });
    }
});