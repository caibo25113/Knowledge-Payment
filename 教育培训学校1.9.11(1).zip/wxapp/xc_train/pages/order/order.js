var t = getApp(), a = require("../common/common.js"), n = 1, e = !1;

Page({
    data: {
        navHref: "",
        tab: [ "全部", "待核销", "已核销", "售后/退款" ],
        tabCurr: 0,
        list: []
    },
    tabChange: function(t) {
        var a = this, n = t.currentTarget.id;
        n != a.data.tabCurr && (a.setData({
            tabCurr: n
        }), a.getData(!0));
    },
    shFunc: function(t) {
        var n = this, e = t.currentTarget.dataset.index, s = n.data.list;
        a.createQrCode(s[e].out_trade_no, "mycanvas", .4), n.setData({
            canshow: !0,
            menu: !0
        });
    },
    canshow: function() {
        this.setData({
            canshow: !1,
            menu: !1,
            menu2: !1
        });
    },
    tui: function(t) {
        var a = this, n = t.currentTarget.dataset.index;
        a.setData({
            tui_index: n,
            menu2: !0,
            canshow: !0
        });
    },
    menu_close: function() {
        this.setData({
            menu2: !1,
            canshow: !1
        });
    },
    input: function(t) {
        this.setData({
            content: t.detail.value
        });
    },
    menu_btn: function() {
        var a = this;
        "" != a.data.content && null != a.data.content ? t.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "mall_tui",
                id: a.data.list[a.data.tui_index].id,
                content: a.data.content
            },
            success: function(t) {
                if ("" != t.data.data) {
                    wx.showToast({
                        title: "提交成功",
                        icon: "success",
                        duration: 2e3
                    });
                    var n = a.data.list;
                    n[a.data.tui_index].status = 2, a.setData({
                        list: n,
                        content: "",
                        menu2: !1,
                        canshow: !1
                    });
                }
            }
        }) : wx.showModal({
            title: "提示",
            content: "请输入退款原因",
            showCancel: !1
        });
    },
    onLoad: function(t) {
        var n = this;
        a.config(n), a.theme(n), n.getData(!0);
    },
    onReady: function() {},
    onShow: function() {
        a.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    onShareAppMessage: function(a) {
        var n = this, e = t.config.webname, s = "/xc_train/pages/base/base", o = "";
        if ("button" === a.from) {
            var i = a.target.dataset.index, u = n.data.list;
            e = u[i].title;
            var r = "/xc_train/pages/shared/shared?&group=" + u[i].group_id;
            s = s + "?&share=" + (r = escape(r)), o = u[i].simg;
        }
        return {
            title: e,
            path: s,
            imageUrl: o,
            success: function(t) {
                console.log(t);
            },
            fail: function(t) {
                console.log(t);
            }
        };
    },
    getData: function(a) {
        var s = this;
        a && (n = 1, e = !1, s.setData({
            list: []
        })), e || t.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "mall_order",
                page: s.data.page,
                pagesize: s.data.pagesize,
                curr: s.data.tabCurr
            },
            success: function(t) {
                var a = t.data;
                wx.stopPullDownRefresh(), "" != a.data ? (n += 1, s.setData({
                    list: s.data.list.concat(a.data)
                })) : e = !0;
            }
        });
    }
});