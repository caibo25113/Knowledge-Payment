var a = getApp(), t = require("../common/common.js"), e = 1, i = !1;

Page({
    data: {
        pagePath: "../service/index",
        curr: -1,
        list: []
    },
    tab: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.curr && (t.setData({
            curr: e
        }), t.getData(!0));
    },
    onLoad: function(e) {
        var i = this;
        t.config(i), t.theme(i), "" != e.curr && null != e.curr && i.setData({
            cid: e.cid
        }), a.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "service_class",
                type: 1
            },
            showLoading: !1,
            success: function(a) {
                var t = a.data;
                if ("" != t.data && (i.setData({
                    pclass: t.data
                }), "" != e.cid && null != e.cid)) for (var s = 0; s < t.data.length; s++) t.data[s].id == e.cid && i.setData({
                    curr: s
                });
            },
            complete: function() {
                i.getData(!0);
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        t.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    onShareAppMessage: function() {
        var t = this, e = "/xc_train/pages/service/index?&cid=" + t.data.pclass[t.data.curr].id;
        return e = escape(e), {
            title: t.data.config.title + "-" + t.data.pclass[t.data.curr].name,
            path: "/xc_train/pages/base/base?&share=" + e + "&share_id=" + a.userinfo.id,
            success: function(a) {
                console.log(a);
            },
            fail: function(a) {
                console.log(a);
            }
        };
    },
    getData: function(t) {
        var s = this;
        if (t && (e = 1, i = !1, s.setData({
            list: []
        })), !i) {
            var c = {
                op: "service",
                page: e,
                pagesize: 20
            };
            -1 != s.data.curr && (c.cid = s.data.pclass[s.data.curr].id), a.util.request({
                url: "entry/wxapp/service",
                data: c,
                success: function(a) {
                    wx.stopPullDownRefresh();
                    var t = a.data;
                    "" != t.data ? (e += 1, s.setData({
                        list: s.data.list.concat(t.data)
                    })) : i = !0;
                }
            });
        }
    }
});