function t(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

function a(t) {
    var a = t.data.store_id, e = t.data.name, s = t.data.mobile, o = t.data.total, i = !0;
    "" != a && null != a || (i = !1), "" != e && null != e || (i = !1), "" != s && null != s || (i = !1), 
    /^(((13[0-9]{1})|(14[0-9]{1})|(17[0-9]{1})|(15[0-3]{1})|(15[5-9]{1})|(18[0-9]{1}))+\d{8})$/.test(s) || (i = !1), 
    "" != o && null != o || (i = !1), t.setData({
        submit: i
    });
}

var e = getApp(), s = require("../common/common.js");

Page({
    data: {
        choose: -1,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        submit: !1,
        store_page: 1,
        store_pagesize: 20,
        store_isbottom: !1,
        is_load: !1
    },
    menu_on: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        a.setData({
            shadow: !0,
            menu: !0,
            choose: e
        });
    },
    menu_close: function() {
        this.setData({
            menu: !1,
            shadow: !1,
            name: "",
            total: "",
            mobile: ""
        });
    },
    choose: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        e != a.data.choose && a.setData({
            choose: e
        });
    },
    input: function(e) {
        var s = this, o = e.currentTarget.dataset.name;
        s.setData(t({}, o, e.detail.value)), a(s);
    },
    store_on: function() {
        this.setData({
            store_pages: !0
        });
    },
    store_choose: function(t) {
        var e = this, s = t.currentTarget.dataset.index;
        e.setData({
            store_id: e.data.store_list[s].id,
            store_name: e.data.store_list[s].name,
            store_pages: !1
        }), a(e);
    },
    store_close: function() {
        this.setData({
            store_pages: !1
        });
    },
    submit: function(t) {
        var a = this, s = t.currentTarget.dataset.index;
        if (-1 == a.data.choose) wx.showModal({
            title: "错误",
            content: "请先选择一门课程！",
            success: function(t) {
                t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
            }
        }); else if (1 == s) wx.navigateTo({
            url: "../sign/sign?&pid=" + a.data.list[a.data.choose].id
        }); else if (2 == s && a.data.submit) {
            var o = {
                pid: a.data.list[a.data.choose].id,
                name: a.data.name,
                mobile: a.data.mobile,
                total: a.data.total,
                form_id: t.detail.formId,
                order_type: s,
                store: a.data.store_id
            };
            e.util.request({
                url: "entry/wxapp/setorder",
                data: o,
                success: function(t) {
                    "" != t.data.data && (a.setData({
                        menu: !1,
                        shadow: !1,
                        name: "",
                        total: "",
                        mobile: ""
                    }), wx.showToast({
                        title: "预约成功",
                        icon: "success",
                        duration: 2e3
                    }));
                }
            });
        }
    },
    store_scroll: function() {
        var t = this;
        if (!t.data.store_isbottom && !t.data.is_load) {
            t.setData({
                is_load: !0
            });
            var a = {
                op: "school",
                page: t.data.store_page,
                pagesize: t.data.store_pagesize
            };
            null != t.data.latitude && "" != t.data.latitude && (a.latitude = t.data.latitude), 
            null != t.data.longitude && "" != t.data.longitude && (a.longitude = t.data.longitude), 
            e.util.request({
                url: "entry/wxapp/index",
                data: a,
                success: function(a) {
                    var e = a.data;
                    "" != e.data ? t.setData({
                        list: t.data.store_list.concat(e.data),
                        page: t.data.store_page + 1
                    }) : t.setData({
                        store_isbottom: !0
                    }), t.setData({
                        is_load: !1
                    });
                }
            });
        }
    },
    onLoad: function(t) {
        var a = this;
        s.config(a), s.theme(a), "" != t.curr && null != t.curr && a.setData({
            curr: t.curr
        }), e.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "list",
                curr: a.data.curr,
                page: a.data.page,
                pagesize: a.data.pagesize
            },
            success: function(t) {
                var e = t.data;
                "" != e.data ? a.setData({
                    list: e.data,
                    page: a.data.page + 1
                }) : a.setData({
                    isbottom: !0
                });
            }
        }), wx.getLocation({
            type: "wgs84",
            success: function(t) {
                var e = t.latitude, s = t.longitude;
                t.speed, t.accuracy;
                a.setData({
                    latitude: e,
                    longitude: s
                });
            },
            complete: function() {
                var t = {
                    op: "school",
                    page: a.data.store_page,
                    pagesize: a.data.store_pagesize
                };
                null != a.data.latitude && "" != a.data.latitude && (t.latitude = a.data.latitude), 
                null != a.data.longitude && "" != a.data.longitude && (t.longitude = a.data.longitude), 
                e.util.request({
                    url: "entry/wxapp/index",
                    data: t,
                    success: function(t) {
                        var e = t.data;
                        "" != e.data ? a.setData({
                            store_list: e.data,
                            page: a.data.store_page + 1
                        }) : a.setData({
                            store_isbottom: !0
                        });
                    }
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        s.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        var t = this;
        t.setData({
            page: 1,
            isbottom: !1
        }), e.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "list",
                curr: t.data.curr,
                page: t.data.page,
                pagesize: t.data.pagesize
            },
            success: function(a) {
                var e = a.data;
                "" != e.data ? (wx.stopPullDownRefresh(), t.setData({
                    list: e.data,
                    page: t.data.page + 1
                })) : t.setData({
                    isbottom: !0
                });
            }
        });
    },
    onReachBottom: function() {
        var t = this;
        t.data.isbottom || e.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "list",
                curr: t.data.curr,
                page: t.data.page,
                pagesize: t.data.pagesize
            },
            success: function(a) {
                var e = a.data;
                "" != e.data ? t.setData({
                    list: t.data.list.concat(e.data),
                    page: t.data.page + 1
                }) : t.setData({
                    isbottom: !0
                });
            }
        });
    }
});