var t = getApp(), a = require("../common/common.js"), e = 1, i = !1;

Page({
    data: {
        curr: 0,
        pclass: [ "我的收藏", "已购音频", "收听历史" ],
        list: []
    },
    tab: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        e != a.data.curr && (a.setData({
            curr: e
        }), a.getData(!0));
    },
    mark: function(a) {
        var e = this, i = a.currentTarget.dataset.index, s = e.data.list;
        t.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "mark",
                id: s[i].pid
            },
            success: function(t) {
                "" != t.data.data && (s.splice(i, 1), wx.showToast({
                    title: "操作成功"
                }), e.setData({
                    list: s
                }));
            }
        });
    },
    history: function(a) {
        var e = this, i = a.currentTarget.dataset.index, s = e.data.list;
        t.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "history",
                id: s[i].id,
                type: 1
            },
            success: function(t) {
                "" != t.data.data && (s.splice(i, 1), wx.showToast({
                    title: "删除成功"
                }), e.setData({
                    list: s
                }));
            }
        });
    },
    onLoad: function(t) {
        var e = this;
        a.config(e), a.theme(e), this.getData(!0);
    },
    onReady: function() {},
    onShow: function() {
        a.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var s = this;
        a && (e = 1, i = !1, s.setData({
            list: []
        })), i || t.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "audio_order",
                curr: s.data.curr,
                page: e,
                pagesize: 20
            },
            success: function(t) {
                var a = t.data;
                wx.stopPullDownRefresh(), "" != a.data ? (e += 1, s.setData({
                    list: s.data.list.concat(a.data)
                })) : i = !0;
            }
        });
    }
});