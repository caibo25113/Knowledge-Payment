var a = getApp(), t = require("../common/common.js"), e = 1, n = !1;

Page({
    data: {
        curr: -1,
        pagePath: "../audio/list",
        list: []
    },
    tab: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.curr && (t.setData({
            curr: e
        }), t.getData(!0));
    },
    onLoad: function(e) {
        var n = this;
        t.config(n), t.theme(n), a.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "audio_class"
            },
            showLoading: !1,
            success: function(a) {
                var t = a.data;
                "" != t.data && n.setData({
                    pclass: t.data
                });
            }
        }), n.getData(!0);
    },
    onReady: function() {},
    onShow: function() {
        t.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(t) {
        var i = this;
        if (t && (e = 1, n = !1, i.setData({
            list: []
        })), !n) {
            var o = {
                op: "audio",
                page: e,
                pagesize: 20
            };
            -1 != i.data.curr && (o.cid = i.data.pclass[i.data.curr].id), a.util.request({
                url: "entry/wxapp/service",
                data: o,
                success: function(a) {
                    var t = a.data;
                    wx.stopPullDownRefresh(), "" != t.data ? (e += 1, i.setData({
                        list: i.data.list.concat(t.data)
                    })) : n = !0;
                }
            });
        }
    }
});