var i = {
    uniacid: "40",
    acid: "40",
    multiid: "0",
    version: "1.0.0",
    siteroot: "https://www.weixin4.cn/app/index.php",
    design_method: "3"
};

module.exports = i;