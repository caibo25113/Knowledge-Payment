App({
    onLaunch: function(i) {
        "" != this.innerAudioContext && null != this.innerAudioContext || (this.innerAudioContext = wx.createInnerAudioContext(), 
        this.innerAudioContext.src = "");
    },
    onShow: function(i) {
        this.service = "", this.audio = "", this.share = "", this.team = "";
        var e = i.query.scene;
        "" != e && null != e && (this[(e = e.split("_"))[0]] = e[1]), "" != i.shareTicket && null != i.shareTicket && (this.shareTicket = i.shareTicket);
    },
    onHide: function() {},
    onError: function(i) {},
    util: require("we7/resource/js/util.js"),
    qr: require("utils/qrcode.js"),
    imageUrl: "/xc_train/resource/",
    pagePath: "/xc_train/pages/",
    globalData: {
        userInfo: null
    },
    mobile: -1,
    siteInfo: require("siteinfo.js"),
    audio_status: !1,
    audio_play: !1,
    audio_Id: "",
    audio_on: ""
});