var t = getApp();

Component({
    properties: {
        tabBar: {
            type: Object,
            value: t.tabBar
        }
    },
    data: {},
    methods: {},
    created: function() {}
});